﻿# -*- coding: utf-8 -*-
"""
Автотесты локальной доски (Selenium + headless Edge).

Запуск:  python tests/test_app.py   (или run_tests.bat)

Поднимаем http.server на временном порту, открываем приложение в headless Edge
и прогоняем сквозные проверки: создание досок и папок, инструменты (перо,
маркер, фигуры, заметки, ластик), undo/redo, выделение, зум, автосохранение
в localStorage, экспорт PNG/PDF (структурная валидация PDF) и файл доски.
"""
import functools
import http.server
import json
import re
import socketserver
import threading
import time
import unittest
import os
import sys
import uuid

from selenium import webdriver
from selenium.webdriver.edge.options import Options as EdgeOptions
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PORT = 8123
BASE = "http://localhost:%d/index.html" % PORT


def start_server():
    # тот же обработчик, что у реального сервера: статика + API realtime-комнат
    sys.path.insert(0, ROOT)
    from serve import Handler as AppHandler

    class Handler(AppHandler):
        def log_error(self, *args):
            pass

    class QuietServer(socketserver.ThreadingTCPServer):
        allow_reuse_address = True
        daemon_threads = True

        def handle_error(self, request, client_address):
            pass

    httpd = QuietServer(("127.0.0.1", PORT), functools.partial(Handler, directory=ROOT))
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    return httpd


class AppTest(unittest.TestCase):
    driver = None

    # ---------- инфраструктура ----------
    @classmethod
    def setUpClass(cls):
        cls.httpd = start_server()
        opts = EdgeOptions()
        opts.add_argument("--headless=new")
        opts.add_argument("--window-size=1400,900")
        opts.add_argument("--disable-gpu")
        opts.add_argument("--no-first-run")
        # фоновые вкладки не должны засыпать: иначе тесты с двумя окнами ловят
        # троттлинг setTimeout и «потерянные» debounce-таймеры
        opts.add_argument("--disable-background-timer-throttling")
        opts.add_argument("--disable-backgrounding-occluded-windows")
        opts.add_argument("--disable-renderer-backgrounding")
        # Edge Sleeping Tabs вешает фоновую вкладку — live-синхронизация в тестах глохнет
        opts.add_argument("--disable-features=SleepingTabs,TabDiscarding,EfficiencyMode")
        try:
            cls.driver = webdriver.Edge(options=opts)
            cls.driver.get(BASE)
            WebDriverWait(cls.driver, 15).until(lambda d: d.execute_script("return !!window.boardApp"))
            cls.arm_dialogs()
        except Exception:
            if cls.driver:
                cls.driver.quit()
                cls.driver = None
            cls.httpd.shutdown()
            raise

    @classmethod
    def tearDownClass(cls):
        if cls.driver:
            cls.driver.quit()
        cls.httpd.shutdown()

    def js(self, code, *args):
        return self.driver.execute_script(code, *args)

    def wait(self, cond, timeout=6):
        WebDriverWait(self.driver, timeout).until(cond)

    @classmethod
    def arm_dialogs(cls):
        """Переопределяем prompt/alert/confirm: prompt берёт ответы из очереди."""
        cls.driver.execute_script("""
            window.__promptQ = []; window.__alerts = [];
            window.prompt = (t, d) => { const v = window.__promptQ.shift(); return v === undefined ? d : v; };
            window.confirm = () => true;
            window.alert = m => window.__alerts.push(String(m));
        """)

    def push_prompt(self, *answers):
        self.driver.execute_script("window.__promptQ = window.__promptQ.concat(arguments[0])", list(answers))

    def state(self):
        return self.js("return JSON.parse(JSON.stringify(window.boardApp.state));")

    def store(self):
        raw = self.js("return localStorage.getItem('local-miro-boards-v1');")
        return json.loads(raw) if raw else None

    def open(self):
        self.wait(EC.invisibility_of_element_located((By.ID, "home")))

    def click(self, css):
        self.driver.find_element(By.CSS_SELECTOR, css).click()

    def pick_tool(self, tool):
        """Выбор инструмента: главный кнопки группы или пункт скрытого меню."""
        self.js("""const el = document.querySelector('.tool[data-tool="' + arguments[0] + '"]') ||
            document.querySelector('.toolgroup .menu-item[data-tool="' + arguments[0] + '"]');
            el.click();""", tool)

    def canvas(self):
        return self.driver.find_element(By.ID, "board")

    # --- мышь через CDP: точные экранные координаты (pointer-события) ---
    def _md(self, x, y, button="left", typ="mousePressed", click_count=1):
        self.driver.execute_cdp_cmd("Input.dispatchMouseEvent",
                                    {"type": typ, "x": x, "y": y, "button": button,
                                     "buttons": 1 if typ != "mouseReleased" else 0, "clickCount": click_count})

    def mouse_move(self, x, y):
        self.driver.execute_cdp_cmd("Input.dispatchMouseEvent",
                                    {"type": "mouseMoved", "x": x, "y": y, "button": "none", "buttons": 0})

    def click_at(self, x, y):
        self._md(x, y, typ="mousePressed", click_count=1)
        self._md(x, y, typ="mouseReleased", click_count=1)

    def wheel(self, x, y, delta, ctrl=False):
        """Колесо мыши в точке (x,y); ctrl=True — зум, иначе прокрутка."""
        self.driver.execute_script("""
            document.getElementById('board').dispatchEvent(new WheelEvent('wheel',
                {deltaY: arguments[0], clientX: arguments[1], clientY: arguments[2], ctrlKey: arguments[3],
                 bubbles: true, cancelable: true}));
        """, delta, x, y, ctrl)

    def drag(self, x1, y1, x2, y2, steps=14):
        """Жест на холсте от (x1,y1) до (x2,y2) через серию pointer-событий."""
        self.mouse_move(x1, y1)
        self._md(x1, y1, typ="mousePressed")
        for i in range(1, steps + 1):
            self._md(int(x1 + (x2 - x1) * i / steps), int(y1 + (y2 - y1) * i / steps),
                     typ="mouseMoved")
        self._md(x2, y2, typ="mouseReleased")

    # ---------- тесты ----------
    def test_01_empty_start(self):
        """Свежий запуск: открыта стартовая страница без досок."""
        self.assertTrue(self.js("return document.getElementById('home').classList.contains('open')"))
        self.assertEqual(self.js("return window.boardApp.Store.raw().list.length"), 0)
        self.assertIn("Пока пусто", self.driver.find_element(By.CSS_SELECTOR, ".empty-note").text)

    def test_02_create_board_no_autowalkin(self):
        """Создание доски добавляет карточку, но НЕ заходит в неё."""
        self.push_prompt("Моя доска")
        self.click("#homeNew")
        self.wait(lambda d: d.execute_script("return window.boardApp.Store.raw().list.length") == 1)
        self.assertEqual(self.state()["objects"], [])
        self.assertTrue(self.js("return document.getElementById('home').classList.contains('open')"))
        self.assertEqual(len(self.driver.find_elements(By.CSS_SELECTOR, "#boardGrid .card:not(.fcard)")), 1)

    def test_03_open_board(self):
        self.click("#boardGrid .card:not(.fcard)")
        self.open()
        self.assertEqual(self.js("return document.getElementById('curBoardName').textContent"), "Моя доска")

    def test_04_pen_stroke(self):
        self.js("window.boardApp.Store.board().objects = []; window.boardApp.state.objects = [];")
        self.pick_tool("pen")
        self.drag(300, 300, 600, 360)
        objs = self.state()["objects"]
        self.assertEqual(len(objs), 1)
        self.assertEqual(objs[0]["type"], "path")
        self.assertGreater(len(objs[0]["points"]), 1)
        self.assertTrue(objs[0].get("width", 0) >= 1)

    def test_05_marker_stroke(self):
        self.pick_tool("marker")
        self.drag(300, 420, 560, 450)
        o = self.state()["objects"][-1]
        self.assertEqual(o["type"], "path")
        self.assertTrue(o.get("hl"))
        self.assertGreaterEqual(o["width"], 14)

    def test_06_rect_and_dash_line(self):
        self.pick_tool("rect")
        self.drag(700, 200, 860, 320)
        rect = self.state()["objects"][-1]
        self.assertEqual(rect["type"], "rect")
        self.assertGreater(rect["w"], 3)
        self.assertGreater(rect["h"], 3)
        self.pick_tool("dline")
        self.drag(700, 400, 900, 500)
        line = self.state()["objects"][-1]
        self.assertEqual(line["type"], "line")
        self.assertTrue(line.get("dash"))

    def test_07_note_create_edit(self):
        self.pick_tool("note")
        self.click_at(400, 600)
        self.wait(lambda d: d.execute_script("return !!window.boardApp.session.editing"))
        editor = self.driver.find_element(By.ID, "editor")
        editor.send_keys("Привет, доска!")
        self.js("document.getElementById('editor').blur()")
        self.wait(lambda d: not d.execute_script("return !!window.boardApp.session.editing"))
        note = self.state()["objects"][-1]
        self.assertEqual(note["type"], "note")
        self.assertIn("Привет", note["text"])

    def test_08_eraser_removes(self):
        before = len(self.state()["objects"])
        self.pick_tool("eraser")
        rect = [o for o in self.state()["objects"] if o["type"] == "rect"][0]
        sx = rect["x"] + rect["w"] / 2
        sy = rect["y"] + rect["h"] / 2
        # мир -> экран: экран = мир*scale + offset (scale=1 по умолчанию)
        self.click_at(int(sx), int(sy))
        self.wait(lambda d: len(d.execute_script("return window.boardApp.state.objects")) == before - 1)

    def test_09_select_and_delete_key(self):
        self.pick_tool("select")
        line = [o for o in self.state()["objects"] if o["type"] == "line"][0]
        mx = (line["x1"] + line["x2"]) / 2
        my = (line["y1"] + line["y2"]) / 2
        before = len(self.state()["objects"])
        self.click_at(int(mx), int(my))
        self.wait(lambda d: d.execute_script("return window.boardApp.state.selection") is not None)
        ActionChains(self.driver).send_keys(Keys.DELETE).perform()
        self.wait(lambda d: len(d.execute_script("return window.boardApp.state.objects")) == before - 1)

    def test_10_undo_redo(self):
        """undo откатывает последний шаг, redo возвращает."""
        self.js("window.boardApp.state.view = {x:0,y:0,scale:1}; window.boardApp.render();")
        before = self.js("return JSON.stringify(window.boardApp.state.objects)")
        self.pick_tool("pen")
        self.drag(150, 150, 350, 200)
        during = self.js("return JSON.stringify(window.boardApp.state.objects)")
        self.assertNotEqual(before, during)
        self.js("window.boardApp.undo()")
        self.assertEqual(self.js("return JSON.stringify(window.boardApp.state.objects)"), before)
        self.js("window.boardApp.redo()")
        self.assertEqual(self.js("return JSON.stringify(window.boardApp.state.objects)"), during)

    def test_11_zoom_wheel(self):
        """Ctrl+колесо: вверх — крупнее, вниз — мельче; якорь под курсором; клампы min/max."""
        self.js("window.boardApp.state.view = {x:0, y:0, scale:1}; window.boardApp.render();")
        cx, cy = 600, 400

        def world_x_under_cursor():
            return self.js("return (arguments[0] - window.boardApp.state.view.x) / window.boardApp.state.view.scale;", cx)

        self.wheel(cx, cy, -300, ctrl=True)  # вверх
        self.assertGreater(self.state()["view"]["scale"], 1.05)
        self.assertAlmostEqual(world_x_under_cursor(), cx, delta=0.5)  # точка под курсором не уплыла

        for _ in range(4):        # вниз — меньше исходной
            self.wheel(cx, cy, 300, ctrl=True)
        self.assertLess(self.state()["view"]["scale"], 0.99)

        for _ in range(40):       # кламп снизу
            self.wheel(cx, cy, 1000, ctrl=True)
        self.assertAlmostEqual(self.state()["view"]["scale"], self.js("return window.boardApp.CFG.ZOOM_MIN"))

        for _ in range(80):       # кламп сверху
            self.wheel(cx, cy, -1000, ctrl=True)
        self.assertAlmostEqual(self.state()["view"]["scale"], self.js("return window.boardApp.CFG.ZOOM_MAX"))

        self.click("#zoomReset")
        self.assertEqual(self.state()["view"]["scale"], 1)

    def test_11b_scroll_pan(self):
        """Обычное колесо — крупная прокрутка вниз/вверх; горизонталь и зум не трогаются."""
        self.js("window.boardApp.state.view = {x:100, y:0, scale:1}; window.boardApp.render();")
        step = self.js("return window.boardApp.CFG.PAN_WHEEL")
        self.wheel(600, 400, 300)
        v = self.state()["view"]
        self.assertAlmostEqual(v["y"], -300 * step, delta=1, msg="прокрутка вниз большая")
        self.assertEqual(v["x"], 100, "горизонталь — как есть")
        self.assertEqual(v["scale"], 1, "зум не меняется")
        self.wheel(600, 400, -300)
        self.assertAlmostEqual(self.state()["view"]["y"], 0, delta=1)
        self.wheel(600, 400, 300, ctrl=True)  # ctrl — это зум, не скролл
        self.assertLess(self.state()["view"]["scale"], 1)

    def test_12_pan_space(self):
        self.js("window.boardApp.session.spaceDown = true;")
        vx0 = self.state()["view"]["x"]
        self.drag(1000, 600, 800, 500)  # в стороне от нижнего тулбара
        self.js("window.boardApp.session.spaceDown = false;")
        self.assertAlmostEqual(self.state()["view"]["x"], vx0 - 200, delta=3)

    def test_13_autosave(self):
        time.sleep(0.7)
        n_state = len(self.state()["objects"])
        n_saved = len(self.store()["list"][0]["objects"])
        self.assertEqual(n_saved, n_state)
        self.assertGreater(n_saved, 0)

    def test_14_reload_persistence(self):
        self.driver.refresh()
        self.wait(lambda d: d.execute_script("return !!window.boardApp"))
        self.arm_dialogs()
        self.assertTrue(self.js("return document.getElementById('home').classList.contains('open')"))
        self.assertEqual(len(self.store()["list"]), 1)
        self.click("#boardGrid .card:not(.fcard)")
        self.open()
        self.assertEqual(len(self.state()["objects"]), len(self.store()["list"][0]["objects"]))

    def test_15_png_export(self):
        url = self.js("""
            const a = window.boardApp;
            if (!a.state.objects.length) return '';
            return a.renderBoardCanvas(a.state.objects).toDataURL('image/png').slice(0, 22);
        """)
        self.assertEqual(url, "data:image/png;base64,")

    def test_16_pdf_structure(self):
        """PDF: заголовок, xref по смещению из startxref, EOF."""
        self.js("""
            window.__pdf = null;
            const a = window.boardApp;
            a.buildBoardPDFBlob(a.state.objects).then(b => b.arrayBuffer()).then(buf => {
                const u8 = new Uint8Array(buf); let s = '';
                for (let i = 0; i < u8.length; i++) s += String.fromCharCode(u8[i]);
                window.__pdf = s;
            }).catch(e => { window.__pdf = { error: String(e) }; });
        """)
        self.wait(lambda d: d.execute_script("return window.__pdf !== null"), timeout=15)
        s = self.js("return window.__pdf")
        self.assertNotIsInstance(s, dict, s.get("error", "") if isinstance(s, dict) else "")
        self.assertEqual(s[:8], "%PDF-1.4")
        self.assertTrue(s.endswith("%%EOF\n"))
        m = re.search(r"startxref\n(\d+)\n%%EOF", s)
        self.assertIsNotNone(m, "нет таблицы xref")
        off = int(m.group(1))
        self.assertEqual(s[off:off + 4], "xref", "смещение startxref не указывает на 'xref'")
        n = int(re.match(r"xref\n0 (\d+)\n", s[off:]).group(1))
        self.assertGreaterEqual(n, 5)
        self.assertIn("/Type /Page", s)
        self.assertIn("/Contents 4 0 R", s)

    def test_17_board_file_roundtrip(self):
        """serializeBoard -> JSON -> обратно: данные идентичны."""
        self.js("window.boardApp.saveNow()")
        raw = self.js("return window.boardApp.serializeBoard(window.boardApp.Store.board());")
        data = json.loads(raw)
        self.assertEqual(data["app"], "local-board")
        self.assertEqual(data["version"], 2)
        self.assertEqual(len(data["objects"]), len(self.state()["objects"]))

    def test_18_folders(self):
        """Папка создаётся, новая доска попадает в неё."""
        self.click("#boardBtn")
        self.wait(lambda d: d.execute_script("return document.getElementById('home').classList.contains('open')"))
        self.push_prompt("Проект А")
        self.click("#homeNewFolder")
        self.wait(lambda d: len(d.execute_script("return window.boardApp.Store.folders()")) == 1)
        self.assertEqual(len(self.driver.find_elements(By.CSS_SELECTOR, ".fcard")), 1)
        fid = self.js("return window.boardApp.Store.folders()[0].id;")
        self.driver.find_element(By.CSS_SELECTOR, ".fcard").click()
        self.push_prompt("Доска в папке")
        self.click("#homeNew")
        self.wait(lambda d: d.execute_script("return window.boardApp.Store.raw().list.length") == 2)
        board = [b for b in self.store()["list"] if b["name"] == "Доска в папке"][0]
        self.assertEqual(board["folder"], fid)
        self.assertEqual(len(self.driver.find_elements(By.CSS_SELECTOR, "#boardGrid .card:not(.fcard)")), 1)

    def test_19_folder_delete_boards_to_root(self):
        """Удаление папки через UI: доски возвращаются в корень."""
        # после test_18 мы внутри папки — поднимаемся в корень
        crumb = self.driver.find_element(By.CSS_SELECTOR, ".crumb-link")
        crumb.click()
        self.wait(lambda d: d.execute_script("return window.boardApp.session.homeFolder") is None)
        self.driver.find_element(By.CSS_SELECTOR, ".fcard .cactions .cbtn:last-child").click()
        self.wait(lambda d: len(d.execute_script("return window.boardApp.Store.folders()")) == 0)
        for b in self.store()["list"]:
            self.assertIsNone(b["folder"])

    def test_20_toolbox_dropdowns(self):
        """Тулбар внизу; группы инструментов раскрываются и выбирают под-инструмент."""
        self.click("#boardGrid .card:not(.fcard)")
        self.open()
        box = self.js("const r = document.getElementById('toolbar').getBoundingClientRect(); return r.y + r.height / 2;")
        self.assertGreater(box, self.js("return innerHeight / 2"), "тулбар должен быть внизу")
        # карандаш и маркер — отдельные видимые кнопки
        for t in ("pen", "marker"):
            standalone = self.js("const b = document.querySelector('.tool[data-tool=\"' + arguments[0] + '\"]');"
                                 "return !!b && !b.closest('.toolgroup');", t)
            self.assertTrue(standalone, t + " должен быть отдельной кнопкой вне группы")
        group = ".toolgroup[data-tools='line dline arrow']"
        self.js(f'document.querySelector("{group} .tcaret").click()')
        self.assertTrue(self.js(f'return document.querySelector("{group}").classList.contains("menu-open")'))
        self.assertEqual(self.js(f'return getComputedStyle(document.querySelector("{group} .menu")).display'), "flex")
        self.js(f'document.querySelector("{group} .menu-item[data-tool=dline]").click()')
        self.assertEqual(self.state()["tool"], "dline")
        self.assertFalse(self.js(f'return document.querySelector("{group}").classList.contains("menu-open")'))
        self.assertEqual(self.js(f'return document.querySelector("{group} .tool").dataset.tool'), "dline",
                         "главная кнопки группы должна показать выбранный под-инструмент")
        # клик мимо закрывает открытое меню
        self.js('document.querySelector(".toolgroup[data-tools=\'rect ellipse\'] .tcaret").click()')
        self.js("document.body.dispatchEvent(new PointerEvent('pointerdown', {bubbles: true}))")
        self.assertEqual(self.js("return document.querySelectorAll('.menu-open').length"), 0)

    def test_21_export_menu(self):
        """Меню «Экспорт»: открывается, форматы + приглашение, закрытие кликом мимо."""
        self.js("document.getElementById('exportBtn').click()")
        self.assertTrue(self.js("return document.getElementById('exportDrop').classList.contains('menu-open')"))
        self.assertEqual(self.js("return getComputedStyle(document.querySelector('#exportDrop .menu')).display"), "flex")
        self.assertEqual([b["export"] for b in
                          self.js("return [...document.querySelectorAll('#exportDrop [data-export]')].map(x=>({export:x.dataset.export}))")],
                         ["png", "pdf", "json", "share"])
        # «Пригласить по ссылке» из меню экспорта открывает модалку
        self.js("document.querySelector('#exportDrop [data-export=share]').click()")
        self.assertTrue(self.js("return document.getElementById('sharePop').classList.contains('open')"))
        self.js("document.getElementById('shareClose').click()")
        # клик мимо закрывает меню
        self.js("document.getElementById('exportBtn').click()")
        self.js("document.body.dispatchEvent(new PointerEvent('pointerdown', {bubbles: true}))")
        self.assertFalse(self.js("return document.getElementById('exportDrop').classList.contains('menu-open')"))

    def test_22_nudge_copy_paste(self):
        """Стрелки сдвигают выбранное (Shift ×10), Ctrl+C/V — копирование."""
        self.pick_tool("pen")
        self.drag(200, 300, 380, 340)
        self.assertEqual(len(self.state()["objects"]), 1)
        self.pick_tool("select")
        self.click_at(200, 300)
        self.wait(lambda d: d.execute_script("return window.boardApp.state.selection") is not None)
        x0 = self.js("return window.boardApp.state.objects[0].points[0].x")
        y0 = self.js("return window.boardApp.state.objects[0].points[0].y")
        ActionChains(self.driver).send_keys(Keys.ARROW_RIGHT).perform()
        self.assertAlmostEqual(self.js("return window.boardApp.state.objects[0].points[0].x"), x0 + 1, delta=0.01)
        ActionChains(self.driver).key_down(Keys.SHIFT).send_keys(Keys.ARROW_DOWN).key_up(Keys.SHIFT).perform()
        self.assertAlmostEqual(self.js("return window.boardApp.state.objects[0].points[0].y"), y0 + 10, delta=0.01)
        ac = ActionChains(self.driver)
        ac.key_down(Keys.CONTROL).send_keys("c").key_up(Keys.CONTROL).perform()
        ac.key_down(Keys.CONTROL).send_keys("v").key_up(Keys.CONTROL).perform()
        self.assertEqual(len(self.state()["objects"]), 2, "после Ctrl+V должен появиться объект")
        self.assertIsNotNone(self.state()["selection"])

    def test_23_context_menu(self):
        """Правый клик: по пустому — без объектных пунктов; по объекту — порядок слоёв."""
        a_id = self.state()["objects"][0]["id"]
        b_id = self.state()["objects"][1]["id"]  # копия A со смещением +20 (после сдвигов A)

        def right_click(x, y):
            self.js("document.getElementById('board').dispatchEvent(new MouseEvent('contextmenu',"
                    "{clientX: arguments[0], clientY: arguments[1], bubbles: true, cancelable: true}))", x, y)

        right_click(1000, 520)  # пусто
        self.assertTrue(self.js("return document.getElementById('ctxmenu').classList.contains('show')"))
        self.assertEqual(self.js("return getComputedStyle(document.querySelector('#ctxmenu [data-ctx=dup]')).display"), "none")
        self.assertNotEqual(self.js("return getComputedStyle(document.querySelector('#ctxmenu [data-ctx=paste]')).display"), "none")
        bx = self.js("return window.boardApp.state.objects[1].points[0].x")
        by = self.js("return window.boardApp.state.objects[1].points[0].y")
        right_click(int(bx), int(by))  # по копии
        self.assertEqual(self.state()["selection"], b_id)
        self.assertNotEqual(self.js("return getComputedStyle(document.querySelector('#ctxmenu [data-ctx=dup]')).display"), "none")
        self.js("document.querySelector('#ctxmenu [data-ctx=back]').click()")
        self.assertFalse(self.js("return document.getElementById('ctxmenu').classList.contains('show')"))
        ids = [o["id"] for o in self.state()["objects"]]
        self.assertLess(ids.index(b_id), ids.index(a_id), "объект должен уйти на задний план")

    def test_24_fit_and_empty_note(self):
        """«Показать всё» вписывает содержимое; пустая заметка не остаётся."""
        self.click("#fitBtn")
        self.assertGreater(self.state()["view"]["scale"], 2, "вид должен приблизиться к мелкому содержимому")
        n_before = len(self.state()["objects"])
        self.pick_tool("note")
        self.click_at(600, 450)
        self.wait(lambda d: d.execute_script("return !!window.boardApp.session.editing"))
        self.js("document.getElementById('editor').blur()")  # пустая — должна удалиться
        self.wait(lambda d: not d.execute_script("return !!window.boardApp.session.editing"))
        self.assertEqual(len(self.state()["objects"]), n_before)

    def test_25_no_console_errors(self):
        """За всю сессию не было необработанных JS-ошибок."""
        try:
            logs = self.driver.get_log("browser")
        except Exception:
            self.skipTest("драйвер не отдаёт лог браузера")
        bad = [l for l in logs if l.get("level") == "SEVERE"
               and "favicon" not in l.get("message", "").lower()
               and ("Uncaught" in l.get("message", "") or "SyntaxError" in l.get("message", ""))]
        self.assertEqual(bad, [], "консольные ошибки: %s" % bad[:2])

    # ---------- приглашение по ссылке ----------
    def build_share_url(self, role):
        self.js("window.__share = null;"
                "window.boardApp.buildShareLink({name: 'Т', objects: window.boardApp.state.objects, view: window.boardApp.state.view}, arguments[0])"
                ".then(u => window.__share = u).catch(e => window.__share = 'ERR:' + e);", role)
        self.wait(lambda d: d.execute_script("return window.__share !== null"), timeout=15)
        url = self.js("return window.__share")
        self.assertNotIsInstance(url, dict)
        self.assertFalse(str(url).startswith("ERR:"), url)
        return url

    def test_26_share_dialog(self):
        """Диалог «Поделиться»: ссылка с ролью, room = ID доски, ID виден, fallback-снимок."""
        self.assertNotEqual(self.js("return getComputedStyle(document.getElementById('shareBtnTop')).display"), "none",
                            "над открытой доской кнопка в правом углу видна")
        self.js("document.getElementById('shareBtnTop').click()")
        self.assertTrue(self.js("return document.getElementById('sharePop').classList.contains('open')"))
        self.wait(lambda d: d.execute_script("return document.getElementById('shareLink').value.startsWith('http')"), timeout=10)
        link_g = self.js("return document.getElementById('shareLink').value")
        bid = self.js("return window.boardApp.Store.board().id")
        self.assertIn("?room=" + bid, link_g, "live-ссылка строится на ID доски")
        self.assertIn("role=g", link_g, "по умолчанию выбран гость")
        self.assertEqual(self.js("return document.getElementById('shareBoardId').textContent"), bid,
                         "ID доски показан в диалоге")
        self.js("document.querySelector('input[name=\"shareRole\"][value=member]').click()")
        self.wait(lambda d: "role=g" not in d.execute_script("return document.getElementById('shareLink').value")
                  and d.execute_script("return document.getElementById('shareLink').value").startswith("http"), timeout=10)
        # галку live снять -> та же ссылка, но снимок (#share=); вернуть -> снова live
        self.js("document.getElementById('shareLive').click()")
        self.wait(lambda d: "#share=" in d.execute_script("return document.getElementById('shareLink').value"), timeout=15)
        self.js("document.getElementById('shareLive').click()")
        self.wait(lambda d: "?room=" in d.execute_script("return document.getElementById('shareLink').value"), timeout=10)
        self.js("document.getElementById('shareClose').click()")
        self.assertFalse(self.js("return document.getElementById('sharePop').classList.contains('open')"))

    def test_27_guest_link_viewonly(self):
        """Ссылка гостя: доска открыта, правки заблокированы, reload сохраняет роль."""
        url = self.build_share_url("g")
        n = len(self.state()["objects"])
        self.assertGreater(n, 0)
        self.driver.get("about:blank")
        self.driver.get(url)
        self.wait(lambda d: d.execute_script("return !!window.boardApp"))
        st = self.state()
        self.assertTrue(st["readonly"], "гость должен быть в режиме только просмотр")
        self.assertEqual(len(st["objects"]), n)
        self.assertNotEqual(self.js("return getComputedStyle(document.getElementById('saveCopyBtn')).display"), "none",
                         "гостю доступна кнопка сохранения копии")
        self.assertEqual(self.js("return getComputedStyle(document.querySelector('.tool[data-tool=marker]')).pointerEvents"), "none",
                         "редактирующие инструменты должны быть отключены у гостя")
        self.assertEqual(self.js("return getComputedStyle(document.getElementById('topbar')).display"), "none")
        # попытка рисовать и править — безрезультатна
        self.js("document.querySelector('.tool[data-tool=eraser]').click()")  # JS-клик мимо CSS-guard
        self.assertEqual(self.state()["tool"], "select", "setTool должен блокировать правку-инструменты")
        self.drag(300, 300, 460, 340)
        self.assertEqual(len(self.state()["objects"]), n, "гость не может рисовать")
        ActionChains(self.driver).key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).perform()
        self.assertEqual(len(self.state()["objects"]), n)
        # пан пробелом доступен
        self.js("window.boardApp.session.spaceDown = true;")
        vx0 = self.state()["view"]["x"]
        self.drag(900, 400, 700, 400)
        self.js("window.boardApp.session.spaceDown = false;")
        self.assertAlmostEqual(self.state()["view"]["x"], vx0 - 200, delta=3)
        # F5 — снова гость
        self.driver.refresh()
        self.wait(lambda d: d.execute_script("return !!window.boardApp"))
        self.assertTrue(self.state()["readonly"])

    def test_28_member_link_editable(self):
        """Ссылка участника: своя копия доски, можно рисовать, #share убран."""
        before = len(self.store()["list"])
        url = self.build_share_url("p")
        self.driver.get("about:blank")
        self.driver.get(url)
        self.wait(lambda d: d.execute_script("return !!window.boardApp"))
        self.assertFalse(self.state()["readonly"])
        self.assertEqual(self.js("return location.hash"), "", "ссылка участника должна очищаться")
        self.assertEqual(len(self.store()["list"]), before + 1, "у участника появилась своя доска")
        self.assertIn("(общая)", self.js("return document.getElementById('curBoardName').textContent"))
        n = len(self.state()["objects"])
        self.pick_tool("pen")
        self.drag(250, 250, 420, 300)
        self.assertEqual(len(self.state()["objects"]), n + 1, "участник может рисовать")
        self.wait(lambda d: any(b["objects"].__len__() == n + 1 and "(общая)" in b["name"]
                                for b in self.store()["list"]), timeout=5)

    def test_29_share_raw_fallback(self):
        """Без CompressionStream: ссылка с сырым base64 (префикс r) строится и читается."""
        self.js("window.__share = null; window.CompressionStream = undefined;"
                "window.boardApp.buildShareLink({name: 'Т', objects: window.boardApp.state.objects, view: window.boardApp.state.view}, 'p')"
                ".then(u => window.__share = u).catch(e => window.__share = 'ERR:' + e);")
        self.wait(lambda d: d.execute_script("return window.__share !== null"), timeout=15)
        url = self.js("return window.__share")
        self.assertNotIsInstance(url, dict)
        self.assertFalse(str(url).startswith("ERR:"), url)
        self.assertIn("#share=r", url, "ожидался префикс несжатого payload")
        n = len(self.state()["objects"])
        before = len(self.store()["list"])
        self.driver.get("about:blank")
        self.driver.get(url)
        self.wait(lambda d: d.execute_script("return !!window.boardApp"))
        self.assertEqual(len(self.state()["objects"]), n)
        self.assertEqual(len(self.store()["list"]), before + 1)

    # ---------- realtime-сессия (комнаты на сервере) ----------
    def rt_link(self, role):
        """Открывает диалог «Поделиться» и возвращает live-ссылку для роли.

        IP из /api/info в тестах недоступен (сервер слушает только 127.0.0.1),
        поэтому подставляем hostname текущей страницы.
        """
        self.js("window.boardApp.rt.supported = true; window.boardApp.rt.info = {ip: location.hostname};")
        self.js("document.getElementById('shareBtnTop').click()")
        self.js("document.querySelector('input[name=\"shareRole\"][value=%s]').click();" % role)
        self.wait(lambda d: "room=" in d.execute_script("return document.getElementById('shareLink').value")
                  and "role=%s" % ('g' if role == 'guest' else 'p')
                  in d.execute_script("return document.getElementById('shareLink').value"), timeout=10)
        link = self.js("return document.getElementById('shareLink').value")
        self.js("document.getElementById('shareClose').click()")
        return link

    def new_driver(self):
        """Отдельный Edge для «второго человека» (свои вкладки не мешают друг другу)."""
        opts = EdgeOptions()
        opts.add_argument("--headless=new")
        opts.add_argument("--window-size=1400,900")
        opts.add_argument("--disable-gpu")
        opts.add_argument("--no-first-run")
        opts.add_argument("--user-data-dir=" + os.path.join(os.environ.get("TEMP", "."),
                                                            "draw-edge-guest-%s" % uuid.uuid4().hex[:8]))
        return webdriver.Edge(options=opts)

    def drv_drag(self, drv, x1, y1, x2, y2, steps=14):
        """drag() для произвольного драйвера (второе окно живёт в своём Edge)."""
        def md(x, y, typ):
            drv.execute_cdp_cmd("Input.dispatchMouseEvent",
                                {"type": typ, "x": x, "y": y, "button": "left",
                                 "buttons": 1 if typ != "mouseReleased" else 0, "clickCount": 1})
        md(x1, y1, "mouseMoved")
        md(x1, y1, "mousePressed")
        for i in range(1, steps + 1):
            md(int(x1 + (x2 - x1) * i / steps), int(y1 + (y2 - y1) * i / steps), "mouseMoved")
        md(x2, y2, "mouseReleased")
        time.sleep(0.4)

    def test_30_rt_api(self):
        """API сервера: /api/info отвечает, комната хранит доску, rev растёт, since работает."""
        self.js("window.__api = null; fetch('/api/info', {cache:'no-store'}).then(r => r.json()).then(j => window.__api = j);")
        self.wait(lambda d: d.execute_script("return window.__api !== null"))
        self.assertTrue(self.js("return window.__api.ok"))
        self.js("window.__r1 = null; fetch('/api/room/testroom30', {method:'POST',"
                "headers:{'Content-Type':'application/json'},"
                "body: JSON.stringify({name:'R', objects:[{id:'a', type:'rect'}]})})"
                ".then(r => r.json()).then(j => window.__r1 = j);")
        self.wait(lambda d: d.execute_script("return window.__r1 !== null"))
        self.assertEqual(self.js("return window.__r1.rev"), 1)
        self.js("window.__r2 = null; fetch('/api/room/testroom30?since=1', {cache:'no-store'})"
                ".then(r => r.json()).then(j => window.__r2 = j);")
        self.wait(lambda d: d.execute_script("return window.__r2 !== null"))
        self.assertTrue(self.js("return window.__r2.unchanged"), "since=rev -> unchanged")

    def test_31_rt_live_guest(self):
        """Гость по live-ссылке (второй Edge): видит доску, только просмотр, правки хоста доходят."""
        self.driver.get(BASE)
        self.wait(lambda d: d.execute_script("return !!window.boardApp"))
        self.pick_tool("pen")
        self.drag(300, 300, 450, 380)
        n = len(self.state()["objects"])
        self.assertGreater(n, 0)
        link = self.rt_link("guest")
        self.assertIn("?room=", link)
        self.assertIn("role=g", link)
        d2 = self.new_driver()
        try:
            d2.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument",
                               {"source": "window.prompt = () => 'Кот';"})
            d2.get(link)
            WebDriverWait(d2, 20).until(lambda d: d.execute_script("return !!window.boardApp"))
            WebDriverWait(d2, 20).until(lambda d: len(d.execute_script("return window.boardApp.state.objects")) == n)
            self.assertTrue(d2.execute_script("return window.boardApp.state.readonly"))
            self.assertNotEqual(d2.execute_script("return getComputedStyle(document.getElementById('saveCopyBtn')).display"), "none")
            self.assertTrue(d2.execute_script("return document.getElementById('livepill').classList.contains('show')"))
            # приглашённому недоступны «Поделиться» и чужие доски
            self.assertEqual(d2.execute_script(
                "return getComputedStyle(document.getElementById('shareBtnTop')).display"), "none")
            d2.execute_script("document.getElementById('boardBtn').click()")   # проверка JS-защиты
            self.assertFalse(d2.execute_script("return document.getElementById('home').classList.contains('open')"),
                             "гость не должен уходить к списку досок")
            # имя гостя спрашивается при входе и показывается у его курсора
            d2.execute_cdp_cmd("Input.dispatchMouseEvent", {"type": "mouseMoved", "x": 500, "y": 400})
            WebDriverWait(self.driver, 10).until(lambda d: any(
                c["name"] == "Кот" for c in d.execute_script(
                    "return [...window.boardApp.rt.cursors.values()].map(c => ({ name: c.name }))")))
            # «правка хоста»: коммит через продукт (тот же путь, что после рисования:
            # изменение состояния + saveNow -> push); сам мышиный ввод покрыт test_04..12
            self.js("const o = JSON.parse(JSON.stringify(window.boardApp.state.objects[0]));"
                    "o.id = 'probe-' + Date.now(); o.x = (o.x || 0) + 250; o.y = (o.y || 0) + 60;"
                    "window.boardApp.state.objects.push(o); window.boardApp.saveNow();"
                    "window.boardApp.renderNow();")
            self.assertEqual(len(self.state()["objects"]), n + 1, "хост должен добавить объект")
            WebDriverWait(d2, 15).until(lambda d: len(d.execute_script("return window.boardApp.state.objects")) == n + 1)
        finally:
            d2.quit()

    def test_32_rt_live_member_two_way(self):
        """Участник по live-ссылке: рисует, и хост видит его штрих почти сразу."""
        n = len(self.state()["objects"])
        link = self.rt_link("member")
        self.assertIn("role=p", link)
        d2 = self.new_driver()
        try:
            d2.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument",
                               {"source": "window.prompt = () => 'Лис';"})
            d2.get(link)
            WebDriverWait(d2, 20).until(lambda d: d.execute_script("return !!window.boardApp"))
            WebDriverWait(d2, 20).until(lambda d: len(d.execute_script("return window.boardApp.state.objects")) == n)
            self.assertFalse(d2.execute_script("return window.boardApp.state.readonly"))
            # участнику тоже нельзя шарить и ходить по доскам
            self.assertTrue(d2.execute_script("return document.body.classList.contains('invited')"))
            self.assertEqual(d2.execute_script(
                "return getComputedStyle(document.getElementById('shareBtnTop')).display"), "none")
            self.assertEqual(d2.execute_script(
                "return getComputedStyle(document.getElementById('addBoardBtn')).display"), "none")
            d2.execute_script("""const el = document.querySelector('.tool[data-tool="pen"]') ||
                document.querySelector('.toolgroup .menu-item[data-tool="pen"]'); el.click();""")
            self.drv_drag(d2, 280, 420, 430, 470)
            WebDriverWait(d2, 10).until(lambda d: len(d.execute_script("return window.boardApp.state.objects")) == n + 1)
            WebDriverWait(self.driver, 15).until(
                lambda d: len(d.execute_script("return window.boardApp.state.objects")) == n + 1)
        finally:
            d2.quit()

    def test_33_sync_local_folder(self):
        """Синхронизация с папкой: привоз досок и подпапки, выгрузка локальных с ID."""
        self.js("document.getElementById('boardBtn').click()")
        self.wait(lambda d: d.execute_script("return document.getElementById('home').classList.contains('open')"))
        self.assertEqual(self.js("return getComputedStyle(document.getElementById('shareBtnTop')).display"), "none",
                         "на главной кнопки «Поделиться» быть не должно")
        self.js(r"""
        const fileNode = (node, name) => ({
          kind: 'file', name,
          async getFile() { return new File([node.files[name] || ''], name, {type: 'application/json'}); },
          async createWritable() {
            let buf = '';
            return { async write(d) { buf += (typeof d === 'string' ? d : String(d)); },
                     async close() { node.files[name] = buf; } };
          },
        });
        window.__mk = function (node, name, kind) {
          return {
            kind, name,
            async *values() {
              for (const [k, v] of Object.entries(node.files)) {
                if (typeof v === 'string') yield fileNode(node, k);
                else yield window.__mk(v, k, 'directory');
              }
            },
            async getDirectoryHandle(n, o) {
              if (typeof node.files[n] !== 'object' || node.files[n] === null) {
                if (!o || !o.create) throw new Error('NF'); node.files[n] = { files: {} };
              }
              return window.__mk(node.files[n], n, 'directory');
            },
            async getFileHandle(n, o) {
              if (!(n in node.files)) { if (!o || !o.create) throw new Error('NF'); node.files[n] = ''; }
              return fileNode(node, n);
            },
            async queryPermission() { return 'granted'; },
            async requestPermission() { return 'granted'; },
            async removeEntry(n) { delete node.files[n]; },
          };
        };
        const now = Date.now();
        window.__tree = { files: {
          'Альфа.board.json': JSON.stringify({app:'local-board', version:2, name:'Альфа',
            objects:[{id:'a1',type:'rect'}], view:{x:0,y:0,scale:1}, updated: now}),
          'Проекты': { files: {
            'Бета.board.json': JSON.stringify({app:'local-board', version:2, name:'Бета',
              objects:[{id:'b1',type:'rect'},{id:'b2',type:'rect'}], view:{x:1,y:2,scale:1}, updated: now}),
          } },
        }};
        window.showDirectoryPicker = () => Promise.resolve(window.__mk(window.__tree, 'Рабочая', 'directory'));
        """)
        self.js("window.__sync = null; window.boardApp.syncWithFolder()"
                ".then(r => window.__sync = r).catch(e => window.__sync = 'ERR:' + e);")
        self.wait(lambda d: d.execute_script("return window.__sync !== null"), timeout=15)
        r = self.js("return window.__sync")
        self.assertNotIsInstance(r, str, str(r))
        self.assertGreaterEqual(r["imported"], 2, "должны привезтись Альфа и Бета")
        names = {b["name"]: b for b in self.store()["list"]}
        self.assertIn("Альфа", names)
        self.assertIn("Бета", names)
        folders = {f["id"]: f["name"] for f in self.store()["folders"]}
        self.assertEqual(folders.get(names["Бета"]["folder"]), "Проекты", "Бета должна лежать в папке Проекты")
        self.assertIsNone(names["Альфа"]["folder"], "Альфа — в корне")
        # на диске: файл Альфы перезаписан с id, в Проектах появились файлы локальных досок
        alfa = self.js("return window.__tree.files['Альфа.board.json']")
        self.assertIn('"id"', alfa, "файл должен получить идентификатор доски")
        in_proj = self.js("return Object.values(window.__tree.files['Проекты'].files).join('\\n')")
        self.assertIn("Бета", in_proj)
        self.assertIn('"id"', in_proj)

    def test_34_new_board_file_and_delete(self):
        """Новая доска сразу появляется файлом в папке; при удалении файла больше нет."""
        self.js("document.getElementById('boardBtn').click()")
        self.wait(lambda d: d.execute_script("return document.getElementById('home').classList.contains('open')"))
        self.arm_dialogs()   # страница после test_31 перезагружалась — Queue prompt'ов сброшена
        self.push_prompt('Из папки')
        self.js("document.getElementById('homeNew').click()")
        self.wait(lambda d: 'Из папки' in [b['name'] for b in
                    (d.execute_script("return JSON.parse(localStorage.getItem('local-miro-boards-v1'))") or {'list': []})['list']])
        self.wait(lambda d: d.execute_script("return !!window.__tree.files['Из папки.board.json']"), timeout=8)
        bid = self.js("return window.boardApp.Store.raw().list.find(b=>b.name==='Из папки').id")
        self.assertIn(bid, self.js("return window.__tree.files['Из папки.board.json']"),
                      "файл новой доски должен содержать её id")
        self.js("window.__del = null; window.boardApp.removeBoardFile(window.boardApp.Store.raw().list.find(b=>b.name==='Из папки'))"
                ".then(() => window.__del = 1);")
        self.wait(lambda d: d.execute_script("return window.__del === 1"))
        self.assertFalse(self.js("return 'Из папки.board.json' in window.__tree.files"),
                         "удаление доски должно убирать файл")

    def test_35_peer_live_loopback(self):
        """P2P-live (петля): хост раздаёт состояние и пушит изменения, режим peer."""
        self.js("window.boardApp.stopLive();")
        self.js(r"""
        window.__forcePeer = true; window.__pregistry = new Map(); window.__inbox = [];
        function mkConn(pid) {
          const e = {};
          return { peer: pid, open: false,
            on(t, f) { (e[t] = e[t] || []).push(f); },
            once(t, f) { this.on(t, f); }, off() {},
            emit(t, a) { if (t === 'open') this.open = true; (e[t] || []).forEach(f => f(a)); },
            send(m) {} };
        }
        window.__peerFactory = () => function FakePeer(id) {
          const evs = {};
          const self = {
            id: id || 'fake-' + Math.random().toString(36).slice(2),
            destroyed: false,
            on(t, f) { (evs[t] = evs[t] || []).push(f); },
            once(t, f) { self.on(t, f); }, off() {},
            destroy() { self.destroyed = true; window.__pregistry.delete(self.id); },
            emit(t, a) { (evs[t] || []).forEach(f => f(a)); },
            connect(target) {
              const hostPeer = window.__pregistry.get(target);
              const a = mkConn(target), b = mkConn(self.id);
              a.send = m => setTimeout(() => b.emit('data', m), 0);
              b.send = m => setTimeout(() => a.emit('data', m), 0);
              setTimeout(() => { b.emit('open'); a.emit('open'); }, 0);
              if (hostPeer) hostPeer.emit('connection', b);
              else setTimeout(() => self.emit('error', { type: 'peer-unavailable' }), 0);
              return a;
            },
          };
          setTimeout(() => {
            if (id && window.__pregistry.has(id)) { self.emit('error', { type: 'unavailable-id' }); return; }
            window.__pregistry.set(self.id, self);
            self.emit('open', self.id);
          }, 0);
          return self;
        };
        """)
        self.js("window.__host = null; window.boardApp.rtHost('peerloop')"
                ".then(id => window.__host = 'ok:' + id).catch(e => window.__host = 'ERR:' + e);")
        self.wait(lambda d: str(d.execute_script("return window.__host")).startswith("ok:"), timeout=10)
        self.assertEqual(self.js("return window.boardApp.rt.mode"), "peer")
        n = len(self.state()["objects"])
        self.js("""window.__guest = new (window.__peerFactory())();
            window.__c = window.__guest.connect('livedraw-peerloop', {reliable: true});
            window.__c.on('data', d => window.__inbox.push(d));""")
        self.wait(lambda d: d.execute_script("return window.__inbox.length") >= 1, timeout=8)
        first = self.js("return window.__inbox[window.__inbox.length - 1]")
        self.assertEqual(first["t"], "state")
        self.assertEqual(len(first["objects"]), n, "гость получил полное состояние доски")
        self.js("const o = JSON.parse(JSON.stringify(window.boardApp.state.objects[0]));"
                "o.id = 'peer-probe'; window.boardApp.state.objects.push(o); window.boardApp.saveNow();")
        self.wait(lambda d: any(m.get("t") == "state" and len(m["objects"]) == n + 1
                                for m in d.execute_script("return window.__inbox")), timeout=8)
        self.js("window.boardApp.stopLive();")

    def test_36_cursors(self):
        """Живые курсоры: хост рассылает свой, курсоры участников попадают в rt.cursors; серверный путь."""
        # --- P2P путь (петля) ---
        self.js("window.boardApp.stopLive();")
        self.js("window.__forcePeer = true; window.__inbox2 = [];")
        self.js("window.__h2 = null; window.boardApp.rtHost('peerloop3')"
                ".then(id => window.__h2 = 'ok').catch(e => window.__h2 = 'ERR:' + e);")
        self.wait(lambda d: d.execute_script("return window.__h2") == "ok", timeout=10)
        self.js("""window.__guest2 = new (window.__peerFactory())();
            window.__c2 = window.__guest2.connect('livedraw-peerloop3', {reliable: true});
            window.__c2.on('data', d => window.__inbox2.push(d));""")
        self.wait(lambda d: d.execute_script("return window.__inbox2.length") >= 1, timeout=8)
        self.js("if (!window.boardApp.cursorAt) throw new Error('no cursorAt export');")
        self.js("window.boardApp.cursorAt(123, 456);")
        self.wait(lambda d: any(m.get("t") == "cursor" and m.get("x") == 123 and m.get("name") == "Автор"
                                for m in d.execute_script("return window.__inbox2")), timeout=6)
        # курсор гостя долетает до хоста и попадает в карту
        self.js("window.__c2.send({t:'cursor', from:'guest9', name:'Гость zz', color:'#123456', x:50, y:70});")
        self.wait(lambda d: d.execute_script("return [...window.boardApp.rt.cursors.keys()].includes('guest9')"), timeout=6)
        self.assertIn("guest9", self.js("return [...window.boardApp.rt.cursors.keys()]"))
        self.js("window.boardApp.stopLive();")
        self.assertEqual(len(self.js("return [...window.boardApp.rt.cursors.keys()]")), 0,
                         "stopLive должен очищать курсоры")
        # --- серверный путь: POST/GET /api/cursor ---
        self.js("window.__forcePeer = false;")
        self.js("window.boardApp.rt.room = 'cursrv';")
        self.js("window.__cc = null; fetch('/api/cursor/cursrv', {method:'POST',"
                "headers:{'Content-Type':'application/json'},"
                "body: JSON.stringify({from:'zz1', name:'X', color:'#f00', x:1, y:2})})"
                ".then(r => r.json()).then(j => window.__cc = j);")
        self.wait(lambda d: d.execute_script("return window.__cc !== null"))
        self.js("window.__cl = null; fetch('/api/cursor/cursrv?me=' + window.boardApp.rt.tabId,"
                "{cache:'no-store'}).then(r => r.json()).then(j => window.__cl = j.list);")
        self.wait(lambda d: d.execute_script("return window.__cl !== null"))
        lst = self.js("return window.__cl")
        self.assertTrue(any(c["from"] == "zz1" for c in lst), "чужой курсор виден")
        self.js("window.__cl2 = null; fetch('/api/cursor/cursrv?me=zz1',{cache:'no-store'})"
                ".then(r => r.json()).then(j => window.__cl2 = j.list);")
        self.wait(lambda d: d.execute_script("return window.__cl2 !== null"))
        self.assertFalse(any(c["from"] == "zz1" for c in self.js("return window.__cl2")),
                         "me= исключает свой курсор")


if __name__ == "__main__":
    unittest.main(verbosity=2)
