// Глобальное состояние приложения (открытая доска, инструмент, вид)
// и переменные текущего сеанса (жесты, редактор, режим стартовой).
export const state = {
  tool: 'select',
  color: '#2b2f36',
  width: 3,
  objects: [],
  selection: null,
  view: { x: 0, y: 0, scale: 1 },
  readonly: false,    // режим «гость»: только просмотр
};

export const session = {
  draft: null,        // объект, создаваемый прямо сейчас
  drag: null,         // активный жест: pan | move | draw | erase
  spaceDown: false,   // временный пан пробелом
  editing: null,      // объект в текстовом редакторе
  homeFolder: null,   // null = корень, иначе id папки на стартовой
};
