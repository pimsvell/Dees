import { CFG } from './config.js';
import { downloadBlob, fileSafe } from './utils.js';
import { saveNow } from './store.js';

// Сохранение/открытие доски как файла .board.json
// (File System Access API, с фолбэком на обычный download/<input>).

export function serializeBoard(b) {
  return JSON.stringify({ app: CFG.APP_ID, version: CFG.FILE_VERSION, name: b.name, objects: b.objects, view: b.view }, null, 1);
}

export async function saveBoardToFile(b) {
  saveNow();
  const json = serializeBoard(b);
  const fname = fileSafe(b.name) + '.board.json';
  if (window.showSaveFilePicker) {
    try {
      const fh = await showSaveFilePicker({
        suggestedName: fname,
        types: [{ description: 'Доска', accept: { 'application/json': ['.json'] } }],
      });
      const w = await fh.createWritable();
      await w.write(json);
      await w.close();
      return;
    } catch (e) { if (e && e.name === 'AbortError') return; }
  }
  downloadBlob(fname, new Blob([json], { type: 'application/json' }));
}

function pickFile() {
  if (window.showOpenFilePicker) {
    return showOpenFilePicker({ types: [{ description: 'Доска', accept: { 'application/json': ['.json'] } }] })
      .then(h => h[0].getFile())
      .catch(() => null);
  }
  return new Promise(res => {
    const inp = document.getElementById('importFile');
    inp.onchange = () => { const f = inp.files[0]; inp.value = ''; res(f || null); };
    inp.click();
  });
}

// Читает выбранную пользователем файл-доску. null — если не выбрано.
// Бросает исключение при битом файле (ловит вызывающий).
export async function readBoardFile() {
  const file = await pickFile();
  if (!file) return null;
  const d = JSON.parse(await file.text());
  const objects = Array.isArray(d) ? d : d.objects;
  if (!Array.isArray(objects)) throw new Error('bad board file');
  return {
    name: d.name || file.name.replace(/\.json$/i, '') || 'Доска из файла',
    objects,
    view: (d.view && d.view.scale) ? d.view : null,
  };
}
