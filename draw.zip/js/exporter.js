import { CFG } from './config.js';
import { state } from './state.js';
import { fileSafe, downloadBlob, clamp } from './utils.js';
import { objectsBBox } from './scene.js';
import { drawObj, drawNoteText } from './render.js';
import { saveNow } from './store.js';

// Экспорт: PNG (растр) и PDF (вектор).

function dataUrlToBlob(url) {
  const [head, b64] = url.split(',');
  const bin = atob(b64);
  const u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return new Blob([u8], { type: head.match(/:(.*?);/)[1] });
}

export function renderBoardCanvas(objects) {
  const pad = 40, S = 2;
  const { x1, y1, x2, y2 } = objectsBBox(objects);
  const c = document.createElement('canvas');
  c.width = (x2 - x1 + pad * 2) * S; c.height = (y2 - y1 + pad * 2) * S;
  const cc = c.getContext('2d');
  cc.fillStyle = '#ffffff'; cc.fillRect(0, 0, c.width, c.height);
  cc.setTransform(S, 0, 0, S, (-x1 + pad) * S, (-y1 + pad) * S);
  const old = state.view.scale; state.view.scale = 1;
  for (const o of objects) drawObj(cc, o);
  state.view.scale = old;
  return c;
}

export function boardToPNG(objects, filename) {
  if (!objects.length) return alert('Доска пуста');
  downloadBlob(filename, dataUrlToBlob(renderBoardCanvas(objects).toDataURL('image/png')));
}

/* ============================================================================
 * Векторный PDF
 *   фигуры — кубические кривые Безье, заметки — заливки,
 *   маркер — ExtGState (прозрачность + Multiply),
 *   текст — прозрачный растровый слой (кириллицу нельзя встроить без шрифтов).
 * ==========================================================================*/
const P2 = v => Math.round(v * 100) / 100;

function hexRGB(hex) {
  hex = (hex || '#000000').replace('#', '');
  if (hex.length === 3) hex = [...hex].map(c => c + c).join('');
  const v = parseInt(hex, 16);
  return [((v >> 16) & 255) / 255, ((v >> 8) & 255) / 255, (v & 255) / 255].map(x => x.toFixed(3)).join(' ');
}

function pdfRRect(x, y, w, h, r) {
  r = Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2);
  const k = r * 0.5523;
  return [
    P2(x + r) + ' ' + P2(y) + ' m',
    P2(x + w - r) + ' ' + P2(y) + ' l',
    P2(x + w - r + k) + ' ' + P2(y) + ' ' + P2(x + w) + ' ' + P2(y + r - k) + ' ' + P2(x + w) + ' ' + P2(y + r) + ' c',
    P2(x + w) + ' ' + P2(y + h - r) + ' l',
    P2(x + w) + ' ' + P2(y + h - r + k) + ' ' + P2(x + w - r + k) + ' ' + P2(y + h) + ' ' + P2(x + w - r) + ' ' + P2(y + h) + ' c',
    P2(x + r) + ' ' + P2(y + h) + ' l',
    P2(x + r - k) + ' ' + P2(y + h) + ' ' + P2(x) + ' ' + P2(y + h - r + k) + ' ' + P2(x) + ' ' + P2(y + h - r) + ' c',
    P2(x) + ' ' + P2(y + r) + ' l',
    P2(x) + ' ' + P2(y + r - k) + ' ' + P2(x + r - k) + ' ' + P2(y) + ' ' + P2(x + r) + ' ' + P2(y) + ' c',
  ].join('\n');
}

function pdfEllipse(cx, cy, rx, ry) {
  const kx = rx * 0.5523, ky = ry * 0.5523;
  return [
    P2(cx - rx) + ' ' + P2(cy) + ' m',
    P2(cx - rx) + ' ' + P2(cy - ky) + ' ' + P2(cx - kx) + ' ' + P2(cy - ry) + ' ' + P2(cx) + ' ' + P2(cy - ry) + ' c',
    P2(cx + kx) + ' ' + P2(cy - ry) + ' ' + P2(cx + rx) + ' ' + P2(cy - ky) + ' ' + P2(cx + rx) + ' ' + P2(cy) + ' c',
    P2(cx + rx) + ' ' + P2(cy + ky) + ' ' + P2(cx + kx) + ' ' + P2(cy + ry) + ' ' + P2(cx) + ' ' + P2(cy + ry) + ' c',
    P2(cx - kx) + ' ' + P2(cy + ry) + ' ' + P2(cx - rx) + ' ' + P2(cy + ky) + ' ' + P2(cx - rx) + ' ' + P2(cy) + ' c',
  ].join('\n');
}

// квадратичные кривые холста -> кубические (в PDF нет оператора q для кривых)
function pdfPathOps(pts) {
  let s = P2(pts[0].x) + ' ' + P2(pts[0].y) + ' m\n';
  if (pts.length < 3) {
    const l = pts[pts.length - 1];
    return s + P2(l.x) + ' ' + P2(l.y) + ' l\n';
  }
  let cur = pts[0];
  for (let i = 1; i < pts.length - 1; i++) {
    const q = pts[i], ex = (q.x + pts[i + 1].x) / 2, ey = (q.y + pts[i + 1].y) / 2;
    const c1x = cur.x + (q.x - cur.x) * 2 / 3, c1y = cur.y + (q.y - cur.y) * 2 / 3;
    const c2x = ex + (q.x - ex) * 2 / 3, c2y = ey + (q.y - ey) * 2 / 3;
    s += P2(c1x) + ' ' + P2(c1y) + ' ' + P2(c2x) + ' ' + P2(c2y) + ' ' + P2(ex) + ' ' + P2(ey) + ' c\n';
    cur = { x: ex, y: ey };
  }
  return s + P2(pts[pts.length - 1].x) + ' ' + P2(pts[pts.length - 1].y) + ' l\n';
}

function pdfVectorOps(objects, gsRef) {
  let s = '';
  for (const o of objects) {
    if (o.type === 'text') continue;
    if (o.type === 'note') { s += hexRGB(o.fill) + ' rg\n' + pdfRRect(o.x, o.y, o.w, o.h, 6) + '\nf\n'; continue; }
    const hl = o.type === 'path' && o.hl;
    if (hl && gsRef) s += 'q /' + gsRef + ' gs\n';
    s += hexRGB(o.color) + ' RG\n' + P2(o.width) + ' w 1 J 1 j ' +
         (o.dash ? '[' + P2(o.width * 4) + ' ' + P2(o.width * 3) + '] 0 d' : '[] 0 d') + '\n';
    if (o.type === 'path') s += pdfPathOps(o.points);
    else if (o.type === 'line') s += P2(o.x1) + ' ' + P2(o.y1) + ' m\n' + P2(o.x2) + ' ' + P2(o.y2) + ' l\n';
    else if (o.type === 'arrow') {
      const a = Math.atan2(o.y2 - o.y1, o.x2 - o.x1), sz = Math.max(10, o.width * 3.2);
      s += P2(o.x1) + ' ' + P2(o.y1) + ' m\n' + P2(o.x2) + ' ' + P2(o.y2) + ' l\n';
      s += P2(o.x2) + ' ' + P2(o.y2) + ' m\n' + P2(o.x2 - sz * Math.cos(a - .45)) + ' ' + P2(o.y2 - sz * Math.sin(a - .45)) + ' l\n';
      s += P2(o.x2) + ' ' + P2(o.y2) + ' m\n' + P2(o.x2 - sz * Math.cos(a + .45)) + ' ' + P2(o.y2 - sz * Math.sin(a + .45)) + ' l\n';
    }
    else if (o.type === 'rect') s += pdfRRect(o.x, o.y, o.w, o.h, 8) + '\n';
    else if (o.type === 'ellipse') s += pdfEllipse(o.x + o.w / 2, o.y + o.h / 2, Math.abs(o.w / 2), Math.abs(o.h / 2)) + '\n';
    s += 'S\n';
    if (hl && gsRef) s += 'Q\n';
  }
  return s;
}

function pdfTextLayer(objects, x1, y1, w, h, pad) {
  if (!objects.some(o => (o.type === 'note' && o.text) || (o.type === 'text' && o.text))) return null;
  const TS = clamp(4096 / Math.max(w, h), 1, 4);
  const cw = Math.max(2, Math.ceil(w * TS)), ch = Math.max(2, Math.ceil(h * TS));
  const c = document.createElement('canvas');
  c.width = cw; c.height = ch;
  const cc = c.getContext('2d');
  cc.setTransform(TS, 0, 0, TS, (-x1 + pad) * TS, (-y1 + pad) * TS);
  cc.textBaseline = 'top';
  for (const o of objects) {
    if (o.type === 'note' && o.text) drawNoteText(cc, o);
    else if (o.type === 'text' && o.text) {
      cc.font = o.fontSize + 'px "Segoe UI", sans-serif';
      cc.fillStyle = o.color;
      o.text.split('\n').forEach((l, i) => cc.fillText(l, o.x, o.y + i * o.fontSize * 1.25));
    }
  }
  const d = cc.getImageData(0, 0, cw, ch).data;
  const rgb = new Uint8Array(cw * ch * 3), a = new Uint8Array(cw * ch);
  for (let i = 0, j = 0; i < cw * ch; i++) {
    rgb[j] = d[i * 4]; rgb[j + 1] = d[i * 4 + 1]; rgb[j + 2] = d[i * 4 + 2]; j += 3;
    a[i] = d[i * 4 + 3];
  }
  return { w: cw, h: ch, rgb, a };
}

async function flate(u8) {
  if (typeof CompressionStream === 'undefined') return null;
  try {
    const res = await new Response(new Blob([u8]).stream().pipeThrough(new CompressionStream('deflate'))).arrayBuffer();
    return new Uint8Array(res);
  } catch (e) { return null; }
}

function assemblePdf(objDefs, W, H, resources) {
  const enc = new TextEncoder();
  const chunks = [];
  let off = 0;
  const offs = [];
  const push = u => { chunks.push(u); off += u.length; };
  const str = s => push(enc.encode(s));
  str('%PDF-1.4\n');
  const total = objDefs.length + 4;
  offs[1] = off; str('1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n');
  offs[2] = off; str('2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n');
  offs[3] = off; str('3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' + W + ' ' + H + '] /Resources << ' + resources + ' >> /Contents 4 0 R >>\nendobj\n');
  objDefs.forEach((def, i) => {
    const num = i + 4;
    offs[num] = off;
    const data = typeof def.data === 'string' ? enc.encode(def.data) : def.data;
    str(num + ' 0 obj\n' + (def.dict || ('<< /Length ' + data.length + ' >>')) + '\n');
    if (data) { str('stream\n'); push(data); str('\nendstream\n'); }
    str('endobj\n');
  });
  const xref = off;
  let x = 'xref\n0 ' + total + '\n0000000000 65535 f \n';
  for (let i = 1; i < total; i++) x += offs[i].toString().padStart(10, '0') + ' 00000 n \n';
  str(x + 'trailer\n<< /Size ' + total + ' /Root 1 0 R >>\nstartxref\n' + xref + '\n%%EOF\n');
  return new Blob(chunks, { type: 'application/pdf' });
}

export async function buildBoardPDFBlob(objects) {
  if (!objects.length) return null;
  const pad = 20;
  const { x1, y1, x2, y2 } = objectsBBox(objects);
  const w = x2 - x1 + pad * 2, h = y2 - y1 + pad * 2;
  let F = 0.75;
  if (Math.max(w, h) * F > 14000) F = 14000 / Math.max(w, h);   // лимит MediaBox
  const W = P2(w * F), H = P2(h * F);
  const layer = pdfTextLayer(objects, x1, y1, w, h, pad);
  const hasHl = objects.some(o => o.type === 'path' && o.hl);
  const gsRef = hasHl ? 'GS1' : null;
  let content = 'q ' + P2(F) + ' 0 0 ' + P2(-F) + ' ' + P2(F * (pad - x1)) + ' ' + P2(F * (h - pad + y1)) + ' cm\n'
              + pdfVectorOps(objects, gsRef) + 'Q\n';
  if (layer) content += 'q ' + W + ' 0 0 ' + H + ' 0 0 cm /Im1 Do Q\n';
  const objDefs = [{ data: content }];
  const res = [];
  if (layer) {
    const rz = await flate(layer.rgb), az = await flate(layer.a);
    const rgbD = rz || layer.rgb, aD = az || layer.a;
    const flg = rz ? ' /Filter /FlateDecode /DecodeParms << /Colors 3 /BitsPerComponent 8 /Columns ' + layer.w + ' >>' : '';
    const fla = az ? ' /Filter /FlateDecode /DecodeParms << /Colors 1 /BitsPerComponent 8 /Columns ' + layer.w + ' >>' : '';
    objDefs.push({ dict: '<< /Type /XObject /Subtype /Image /Width ' + layer.w + ' /Height ' + layer.h +
      ' /ColorSpace /DeviceRGB /BitsPerComponent 8' + flg + ' /SMask 6 0 R /Length ' + rgbD.length + ' >>', data: rgbD });
    objDefs.push({ dict: '<< /Type /XObject /Subtype /Image /Width ' + layer.w + ' /Height ' + layer.h +
      ' /ColorSpace /DeviceGray /BitsPerComponent 8' + fla + ' /Length ' + aD.length + ' >>', data: aD });
    res.push('/XObject << /Im1 5 0 R >>');
  }
  if (hasHl) {
    objDefs.push({ dict: '<< /Type /ExtGState /CA ' + CFG.HL_ALPHA + ' /ca ' + CFG.HL_ALPHA + ' /BM /Multiply >>' });
    res.push('/ExtGState << /GS1 ' + (objDefs.length + 3) + ' 0 R >>');
  }
  return assemblePdf(objDefs, W, H, res.join(' '));
}
export async function boardToPDF(objects, filename) {
  const blob = await buildBoardPDFBlob(objects);
  if (!blob) return alert('Доска пуста');
  downloadBlob(filename, blob);
}

/* --- удобные обёртки --- */
const stamp = () => new Date().toISOString().slice(0, 10);
export const exportCurrentPNG = () => boardToPNG(state.objects, 'board-' + stamp() + '.png');
export const exportCurrentPDF = () => boardToPDF(state.objects, 'board-' + stamp() + '.pdf');
export const exportBoardPNG = b => { saveNow(); boardToPNG(b.objects || [], fileSafe(b.name) + '.png'); };
export const exportBoardPDF = b => { saveNow(); boardToPDF(b.objects || [], fileSafe(b.name) + '.pdf'); };
