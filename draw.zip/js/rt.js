import { state, session } from './state.js';
import { renderNow, addOverlay } from './render.js';
import { setStatus } from './utils.js';

// Realtime-сессия. Два транспорта:
//  - 'server': комнаты на /api/room встроенного сервера (serve.py, локалка/LAN);
//  - 'peer'  : P2P через PeerJS (GitHub Pages и любой статический хостинг) —
//              вкладка хоста сама становится «сервером» доски.
// Хост — вещает открытую доску; гость — живой просмотр (read-only);
// участник — живое редактирование, его правки видят все.
// Последняя запись побеждает (last-write-wins).

export const rt = {
  room: null, role: null,   // 'host' | 'guest' | 'member'
  mode: null,               // 'server' | 'peer'
  rev: 0, supported: null, info: null,
  timer: 0, pushTimer: 0, cursorTimer: 0, dirtyAt: 0, lastPush: 0,
  peer: null, conn: null, lib: null,
  cursors: new Map(), userName: '',
  tabId: Math.random().toString(36).slice(2, 10),
};

const qs = new URLSearchParams(location.search);
if (qs.get('room') && /^[A-Za-z0-9_-]{4,40}$/.test(qs.get('room'))) {
  rt.room = qs.get('room');
  rt.role = qs.get('role') === 'g' ? 'guest' : 'member';
}

function api(path, opts) {
  return fetch('/api/room/' + path, Object.assign({ cache: 'no-store' }, opts));
}

// Отладочные рычаги (только на localhost): __forcePeer — всегда P2P, __peerFactory — своя Peer-реализация.
const IS_LOCAL = ['localhost', '127.0.0.1'].includes(location.hostname);

export async function rtSupported() {
  if (IS_LOCAL && window.__forcePeer) return false;
  if (rt.supported !== null) return rt.supported;
  try {
    const r = await fetch('/api/info', { cache: 'no-store' });
    rt.supported = r.ok;
    rt.info = r.ok ? await r.json() : null;
  } catch (e) { rt.supported = false; }
  return rt.supported;
}

// Адрес, по которому доску увидят другие устройства (LAN IP вместо localhost)
export function rtPublicBase() {
  const host = (rt.info && rt.info.ip) || location.hostname || 'localhost';
  const port = location.port || (location.protocol === 'https:' ? 443 : 80);
  return location.protocol + '//' + host + ':' + port;
}

export function makeRoomId() {
  const a = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  const buf = new Uint8Array(10);
  crypto.getRandomValues(buf);
  let s = '';
  for (const b of buf) s += a[b % a.length];
  return s;
}

async function pushNow(id) {
  const name = ((document.getElementById('curBoardName') || {}).textContent || 'Доска').trim();
  const r = await api(id, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, objects: state.objects }),
  });
  if (!r.ok) throw new Error('server: ' + r.status);
  rt.rev = (await r.json()).rev;
}

// вызывается из store.saveNow после любой локальной правки
export function schedulePush() {
  if (!rt.room || state.readonly || (rt.role !== 'host' && rt.role !== 'member')) return;
  rt.dirtyAt = Date.now();
  clearTimeout(rt.pushTimer);
  const wait = Date.now() - rt.lastPush > 1200 ? 0 : 250;  // свежее событие — сразу
  rt.pushTimer = setTimeout(() => {
    rt.lastPush = Date.now();
    if (rt.mode === 'peer') {
      if (rt.role === 'host') peerBroadcast(peerMsg('state'));
      else if (rt.conn && rt.conn.open) peerSend(rt.conn, peerMsg('push'));
      return;
    }
    pushNow(rt.room).catch(() => {});
  }, wait);
}

function applyRemote(j) {
  if (!j || typeof j.rev !== 'number') return;
  rt.rev = Math.max(rt.rev, j.rev);
  if (session.drag || session.draft || session.editing) return;  // не перебиваем жест
  if (Date.now() - rt.dirtyAt < 1500) return;                    // наш push свежее
  if (Array.isArray(j.objects)) {
    state.objects = j.objects;
    state.selection = null;
    const nameEl = document.getElementById('curBoardName');
    if (nameEl && j.name) nameEl.textContent = j.name;
    renderNow();
  }
}

function startPull() {
  clearInterval(rt.timer);
  rt.timer = setInterval(async () => {
    if (!rt.room) { clearInterval(rt.timer); return; }
    try {
      const r = await api(rt.room + '?since=' + rt.rev);
      if (r.status === 404) { stopLive(); return; }
      if (!r.ok) return;
      const j = await r.json();
      if (!j.unchanged) applyRemote(j);
    } catch (e) { /* сервер мигнул — пододаём следующий тик */ }
  }, 700);
  startCursorPull();
}

// Курсоры — отдельным быстрым таймером: дёшево и заметно плавнее.
function startCursorPull() {
  clearInterval(rt.cursorTimer);
  rt.cursorTimer = setInterval(async () => {
    if (!rt.room || rt.mode !== 'server') { clearInterval(rt.cursorTimer); return; }
    if (document.hidden) return;   // скрытая вкладка не долбит сервер
    try {
      const cr = await fetch('/api/cursor/' + rt.room + '?me=' + rt.tabId, { cache: 'no-store' });
      if (cr.ok) { const cj = await cr.json(); for (const d of (cj.list || [])) putCursor(d); }
    } catch (e) { /* курсы — не критично */ }
  }, 25);
}

document.addEventListener('visibilitychange', () => {
  if (!document.hidden && rt.room && rt.mode === 'server') startCursorPull();
});

function pill(on) {
  const p = document.getElementById('livepill');
  if (p) p.classList.toggle('show', on);
}

export function stopLive() {
  clearInterval(rt.timer);
  clearInterval(rt.cursorTimer);
  clearTimeout(rt.pushTimer);
  cancelAnimationFrame(cursorLoop); cursorLoop = 0;
  if (rt.peer) { try { rt.peer.destroy(); } catch (e) {} rt.peer = null; }
  rt.conn = null; rt.mode = null;
  peerConns.clear();
  rt.cursors.clear();
  rt.room = null; rt.role = null; rt.rev = 0; rt.dirtyAt = 0;
  pill(false);
}

// хост: начать вещание (транспорт выбираем сам: сервер или P2P)
export async function rtHost(id) {
  if (await rtSupported()) return rtHostServer(id);
  return rtHostPeer(id);
}

async function rtHostServer(id) {
  rt.room = id; rt.role = 'host'; rt.mode = 'server'; rt.dirtyAt = 0;
  await pushNow(id);
  startPull();
  pill(true);
  return id;
}

// гость/участник: войти в live по ссылке (транспорт — сам)
export async function rtJoin() {
  if (rt.role === 'guest' || rt.role === 'member') setTimeout(askVisitorName, 300);
  if (await rtSupported()) return rtJoinServer();
  return rtJoinPeer(rt.room);
}

async function rtJoinServer() {
  state.readonly = rt.role === 'guest';
  rt.mode = 'server';
  rt.dirtyAt = 0;
  try {
    const r = await api(rt.room);
    if (r.ok) {
      const j = await r.json();
      rt.rev = j.rev || 0;
      if (Array.isArray(j.objects)) {
        state.objects = j.objects;
        const nameEl = document.getElementById('curBoardName');
        if (nameEl && j.name) nameEl.textContent = j.name;
        renderNow();
      }
    }
  } catch (e) { /* комната ещё не создана — дождёмся по pull */ }
  startPull();
  pill(true);
}

/* ================= P2P-транспорт (PeerJS) ================= */
const PEER_PREFIX = 'livedraw-';
const peerConns = new Set();

// STUN — определение реального адреса, TURN — ретрансляция там, где P2P напрямую не проходит.
const PEER_OPTS = { config: { iceServers: [
  { urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] },
  { urls: 'turn:openrelay.metered.ca:80', username: 'openrelayproject', credential: 'openrelayproject' },
  { urls: 'turn:openrelay.metered.ca:443', username: 'openrelayproject', credential: 'openrelayproject' },
] } };

async function peerLib() {
  if (rt.lib) return rt.lib;
  if (IS_LOCAL && window.__peerFactory) return rt.lib = { Peer: window.__peerFactory() };
  const m = await import('https://esm.sh/peerjs@1.5.4');
  return rt.lib = { Peer: m.default || m.Peer };
}

function boardName() { return ((document.getElementById('curBoardName') || {}).textContent || 'Доска').trim(); }
function peerMsg(t) { return { t, from: rt.tabId, rev: Date.now(), name: boardName(), objects: state.objects }; }
function peerSend(c, m) { try { c.send(m); } catch (e) {} }
function peerBroadcast(m) { for (const c of peerConns) peerSend(c, m); }
function peerCount() {
  const p = document.getElementById('livepill');
  if (p) p.title = 'Live-сессия, подключено: ' + peerConns.size;
}

function peerOpen(p) {
  return new Promise((res, rej) => {
    const to = setTimeout(() => rej(new Error('peer: таймаут подключения')), 9000);
    p.once('open', () => { clearTimeout(to); res(); });
    p.once('error', e => { clearTimeout(to); rej(new Error('peer:' + ((e && e.type) || e))); });
  });
}

async function rtHostPeer(id) {
  if (rt.mode === 'peer' && rt.role === 'host' && rt.room === id && rt.peer) {
    peerBroadcast(peerMsg('state'));
    return id;
  }
  const lib = await peerLib();
  const p = new lib.Peer(PEER_PREFIX + id, PEER_OPTS);
  try {
    await peerOpen(p);
  } catch (e) {
    try { p.destroy(); } catch (e2) {}
    if (String(e.message).indexOf('unavailable') !== -1) {   // эту доску уже ведёт другая вкладка
      await rtJoinPeer(id, 'member');
      setStatus('Эта доска уже ведёт live-сессю — вы подключены к ней как участник.');
      return id;
    }
    throw e;
  }
  rt.peer = p; rt.room = id; rt.role = 'host'; rt.mode = 'peer'; rt.dirtyAt = 0;
  p.on('connection', c => {
    c.on('open', () => { peerConns.add(c); peerSend(c, peerMsg('state')); peerCount(); });
    c.on('data', d => {
      if (!d || d.from === rt.tabId) return;
      if (d.t === 'cursor') { for (const o of peerConns) if (o !== c) peerSend(o, d); putCursor(d); return; }
      if (d.t !== 'push') return;
      applyRemote(d);
      peerBroadcast(peerMsg('state'));            // правку участника видят все
    });
    c.on('close', () => { peerConns.delete(c); peerCount(); });
  });
  pill(true);
  return id;
}

async function rtJoinPeer(id, role) {
  const lib = await peerLib();
  rt.role = role || rt.role || 'guest';
  const p = new lib.Peer(PEER_OPTS);
  await peerOpen(p);
  rt.peer = p; rt.room = id; rt.mode = 'peer';
  state.readonly = rt.role === 'guest';
  p.on('error', e => {
    if (e && e.type === 'peer-unavailable')
      setStatus('Хост live ещё не в сети — попросите открыть доску и нажать «Поделиться».');
  });
  const c = p.connect(PEER_PREFIX + id, { reliable: true });
  rt.conn = c;
  c.on('data', d => {
    if (!d || d.from === rt.tabId) return;
    if (d.t === 'cursor') { putCursor(d); return; }
    if (d.t === 'state' || d.t === 'push') applyRemote(d);
  });
  c.on('close', () => setStatus('Live-сессия завершена (вкладка хоста закрыта).'));
  pill(true);
}

/* ================= живые курсоры участников ================= */
const CURSOR_COLORS = ['#e53935', '#8e24aa', '#039be5', '#43a047', '#fb8c00', '#00897b', '#6d4c41', '#3949ab'];
function myColor() {
  let h = 0;
  for (const ch of rt.tabId) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return CURSOR_COLORS[h % CURSOR_COLORS.length];
}
function myLabel() {
  if (rt.role === 'host') return 'Автор';
  if (rt.userName) return rt.userName;
  return rt.role === 'member' ? 'Участник' : 'Гость';
}

const NAME_KEY = 'draw-visitor-name';
// Спрашиваем имя при входе гостя/участника (один раз, запоминаем).
export function askVisitorName() {
  if (rt.role === 'host') return;
  let saved = '';
  try { saved = localStorage.getItem(NAME_KEY) || ''; } catch (e) {}
  const answer = window.prompt('Как вас представить остальным участникам?', saved);
  const n = answer === null ? saved : answer.trim().slice(0, 20);
  rt.userName = n;
  if (n) { try { localStorage.setItem(NAME_KEY, n); } catch (e) {} }
  if (lastCur) { cursorSentAt = 0; cursorAt(lastCur.x, lastCur.y); }   // сразу обновить бейдж
}

let cursorSentAt = 0;
let lastCur = null;
// вызывается из tools при движении мыши (мировы координаты)
export function cursorAt(wx, wy) {
  if (!rt.room || document.hidden) return;
  lastCur = { x: wx, y: wy };
  const now = Date.now();
  if (now - cursorSentAt < 30) return;
  cursorSentAt = now;
  const m = { t: 'cursor', from: rt.tabId, name: myLabel(), color: myColor(), x: wx, y: wy };
  if (rt.mode === 'peer') {
    if (rt.role === 'host') peerBroadcast(m);
    else if (rt.conn && rt.conn.open) peerSend(rt.conn, m);
  } else if (rt.mode === 'server') {
    fetch('/api/cursor/' + rt.room, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(m),
    }).catch(() => {});
  }
}

// Приём чужого курсора: цель обновляется данными, а рисуемая позиция
// догоняет её в кадре анимации (интерполяция + короткая экстраполяция),
// поэтому движение плавное даже при опросе раз в 100 мс.
function putCursor(d) {
  if (!d || !d.from || d.from === rt.tabId || typeof d.x !== 'number' || typeof d.y !== 'number') return;
  const now = Date.now();
  const prev = rt.cursors.get(d.from);
  if (!prev) {
    rt.cursors.set(d.from, { x: d.x, y: d.y, tx: d.x, ty: d.y, vx: 0, vy: 0,
      name: d.name || 'Участник', color: d.color || '#888', ts: now });
  } else {
    const dt = now - prev.ts;
    if (dt > 0 && dt < 400) {
      prev.vx = (d.x - prev.tx) / dt;   // пикс/мс для предсказания
      prev.vy = (d.y - prev.ty) / dt;
    } else { prev.vx = 0; prev.vy = 0; }
    prev.tx = d.x; prev.ty = d.y; prev.ts = now;
    if (d.name) prev.name = d.name;
    if (d.color) prev.color = d.color;
  }
  ensureCursorLoop();
}

let cursorLoop = 0;
function ensureCursorLoop() {
  if (cursorLoop) return;
  const step = () => {
    cursorLoop = 0;
    if (!rt.cursors.size) return;
    const now = Date.now();
    let moving = false, changed = false;
    for (const [id, c] of rt.cursors) {
      if (now - c.ts > 4000) { rt.cursors.delete(id); changed = true; continue; }
      let gx = c.tx, gy = c.ty;
      const age = now - c.ts;
      if ((c.vx || c.vy) && age < 220) {   // предсказываем позицию на время задержки
        gx += c.vx * age; gy += c.vy * age;
      }
      const dx = gx - c.x, dy = gy - c.y;
      if (Math.abs(dx) > 0.1 || Math.abs(dy) > 0.1) {
        c.x += dx * 0.35; c.y += dy * 0.35; moving = true;
      } else if (c.x !== gx || c.y !== gy) { c.x = gx; c.y = gy; changed = true; }
    }
    if (moving || changed) renderNow();
    if (moving && rt.cursors.size) cursorLoop = requestAnimationFrame(step);
  };
  cursorLoop = requestAnimationFrame(step);
}

function roundRect(c2d, x, y, w, h, r) {
  c2d.beginPath();
  c2d.moveTo(x + r, y);
  c2d.arcTo(x + w, y, x + w, y + h, r);
  c2d.arcTo(x + w, y + h, x, y + h, r);
  c2d.arcTo(x, y + h, x, y, r);
  c2d.arcTo(x, y, x + w, y, r);
  c2d.closePath();
}

addOverlay((c2d, dpr) => {
  if (!rt.cursors.size) return;
  const now = Date.now();
  c2d.save();
  c2d.setTransform(dpr, 0, 0, dpr, 0, 0);
  for (const [id, cur] of rt.cursors) {
    if (now - cur.ts > 4000) { rt.cursors.delete(id); continue; }
    const sx = cur.x * state.view.scale + state.view.x;
    const sy = cur.y * state.view.scale + state.view.y;
    if (sx < -200 || sy < -60 || sx > innerWidth + 40 || sy > innerHeight + 40) continue;
    c2d.save();
    c2d.translate(sx, sy);
    c2d.beginPath();
    c2d.moveTo(0, 0); c2d.lineTo(0, 15.5); c2d.lineTo(4.2, 12); c2d.lineTo(7.3, 18.4);
    c2d.lineTo(9.8, 17.2); c2d.lineTo(6.7, 10.9); c2d.lineTo(11.8, 10.6); c2d.closePath();
    c2d.fillStyle = cur.color; c2d.strokeStyle = '#fff'; c2d.lineWidth = 1.4;
    c2d.stroke(); c2d.fill();
    c2d.font = '600 11px "Segoe UI", system-ui, sans-serif';
    const w = c2d.measureText(cur.name).width + 14;
    c2d.fillStyle = cur.color;
    roundRect(c2d, 12, 18, w, 19, 9.5);
    c2d.fill();
    c2d.fillStyle = '#fff';
    c2d.textBaseline = 'middle'; c2d.textAlign = 'left';
    c2d.fillText(cur.name, 19, 28);
    c2d.restore();
  }
  c2d.restore();
});
