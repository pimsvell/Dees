import { state } from './state.js';

// Мелкие чистые помощники, не знающие про остальные модули.
export const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
export const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
export const fileSafe = s => (s || 'board').replace(/[\\/:*?"<>|]/g, '_').slice(0, 60);

// экранные координаты -> мировые
export const toWorld = (sx, sy) => ({
  x: (sx - state.view.x) / state.view.scale,
  y: (sy - state.view.y) / state.view.scale,
});

// русская плюрализация: 1 доска / 2 доски / 5 досок
export function plural(n, one, few, many) {
  const m10 = n % 10, m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return one;
  if (m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20)) return few;
  return many;
}

export function setStatus(text) {
  document.getElementById('status').textContent = text;
}

export function downloadBlob(name, blob) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 3000);
}
