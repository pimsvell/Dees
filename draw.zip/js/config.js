// Единая точка настройки приложения.
export const CFG = {
  LS_KEY: 'local-miro-board-v1',        // устаревший ключ (одиночная доска)
  LS_BOARDS: 'local-miro-boards-v1',    // доски + папки
  APP_ID: 'local-board',
  FILE_VERSION: 2,
  HISTORY_MAX: 120,
  ZOOM_MIN: 0.1, ZOOM_MAX: 8, ZOOM_STEP: 1.2, ZOOM_WHEEL: 0.0015,
  PAN_WHEEL: 3,   // обычный wheel = быстрый вертикальный скролл; Ctrl+wheel = зум
  GRID_BASE: 40, GRID_MIN_PX: 28, GRID_MAX_PX: 56,   // экранный шаг точек, px
  GRID_DOT: '#c9ced6', GRID_DOT_R: 1.25,             // цвет и радиус точки (в стиле Miro)
  NOTE_W: 190, NOTE_H: 190, NOTE_FONT: 15, NOTE_LINE: 19, NOTE_FILL: '#fff9a6',
  TEXT_FONT: 28,
  PEN_MIN_STEP: 3,    // мин. шаг пера, экранные px
  RDP_EPS: 0.7,       // упрощение штриха, мировые px
  CHAIKIN_ITERS: 2,   // сглаживание штриха
  HL_ALPHA: 0.35,     // прозрачность маркера
  SAVE_DEBOUNCE_MS: 400,
};
