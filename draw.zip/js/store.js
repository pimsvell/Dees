import { CFG } from './config.js';
import { state, session } from './state.js';
import { uid, setStatus } from './utils.js';
import { schedulePush } from './rt.js';
import { mirrorBoard } from './sync.js';

// Хранилище досок и папок в localStorage.
// Структура: { active: id, list: [board], folders: [folder] }
let store = { active: null, list: [], folders: [] };

export const Store = {
  raw() { return store; },
  board() { return store.list.find(b => b.id === store.active); },
  folders() { return store.folders = store.folders || []; },

  load() {
    let had = false;
    try { const raw = localStorage.getItem(CFG.LS_BOARDS); if (raw) { store = JSON.parse(raw); had = true; } } catch (e) {}
    store.folders = store.folders || [];
    store.list = store.list || [];
    if (!had) Store._migrateLegacy();
    if (!Store.board()) store.active = store.list.length ? store.list[0].id : null;
  },

  _migrateLegacy() {
    let objects = null, view = { x: 0, y: 0, scale: 1 };
    try {
      const old = JSON.parse(localStorage.getItem(CFG.LS_KEY) || 'null');
      if (old) { objects = old.objects || []; if (old.view) view = old.view; }
    } catch (e) {}
    if (!objects) { store = { active: null, list: [], folders: [] }; return; } // чистый старт
    const b = Store.makeBoard('Доска 1');
    b.objects = objects; b.view = view;
    store = { active: b.id, list: [b], folders: [] };
    Store.persist();
  },

  persist() {
    try { localStorage.setItem(CFG.LS_BOARDS, JSON.stringify(store)); }
    catch (e) { setStatus('ошибка сохранения'); }
  },

  makeBoard(name, folder) {
    return { id: uid(), name, folder: folder || null, objects: [], view: { x: 0, y: 0, scale: 1 }, updated: Date.now() };
  },
  addBoard(name, folder) {
    const b = Store.makeBoard(name, folder);
    store.list.unshift(b);
    Store.persist();
    return b;
  },
  removeBoard(b) {
    store.list = store.list.filter(x => x.id !== b.id);
    if (store.active === b.id) store.active = store.list.length ? store.list[0].id : null;
    Store.persist();
  },
  setActive(id) { store.active = id; Store.persist(); },

  addFolder(name) { Store.folders().push({ id: uid(), name }); Store.persist(); },
  removeFolder(f) {
    for (const b of store.list) if (b.folder === f.id) b.folder = null;
    store.folders = Store.folders().filter(x => x.id !== f.id);
    if (session.homeFolder === f.id) session.homeFolder = null;
    Store.persist();
  },
};

// Сохраняет текущее состояние открытой доски в store.
let saveTimer = null;
export function saveNow() {
  schedulePush();                      // realtime: разослать правку в комнату
  if (state.readonly) return;            // гость ничего не пишет в локальное хранилище
  const b = Store.board();
  if (!b) return;
  b.objects = state.objects;
  b.view = state.view;
  b.updated = Date.now();
  Store.persist();
  mirrorBoard(b);                      // если выбрана локальная папка — обновим файл
}
export function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    saveNow();
    const b = Store.board();
    if (b) setStatus('«' + b.name + '» сохранено ' + new Date().toLocaleTimeString());
  }, CFG.SAVE_DEBOUNCE_MS);
}
