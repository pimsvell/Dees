import { CFG } from './config.js';
import { state, session } from './state.js';
import { clamp } from './utils.js';
import { bbox, wrapText, findTopAt, objectsBBox } from './scene.js';

// Отрисовка доски на canvas: сетка, объекты, выделение, миниатюры.

export const canvas = document.getElementById('board');
export const ctx = canvas.getContext('2d');
const zoomLabel = document.getElementById('zoomLabel');

export function resize() {
  const dpr = window.devicePixelRatio || 1;
  canvas.width = innerWidth * dpr;
  canvas.height = innerHeight * dpr;
  canvas.style.width = innerWidth + 'px';
  canvas.style.height = innerHeight + 'px';
  render();
}

// Отрисовка через requestAnimationFrame: максимум раз в кадр.
let renderQueued = false;
export function render() {
  if (renderQueued) return;
  renderQueued = true;
  requestAnimationFrame(() => { renderQueued = false; renderNow(); });
}

export function renderNow() {
  cursorCacheReset();
  const dpr = window.devicePixelRatio || 1;
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  drawGrid();
  const { x, y, scale } = state.view;
  ctx.setTransform(dpr * scale, 0, 0, dpr * scale, dpr * x, dpr * y);
  // отсечение невидимого
  const vx = -x / scale, vy = -y / scale, vw = innerWidth / scale, vh = innerHeight / scale;
  for (const o of state.objects) {
    const b = bbox(o);
    if (!b || b.x + b.w < vx || b.x > vx + vw || b.y + b.h < vy || b.y > vy + vh) continue;
    drawObj(ctx, o);
  }
  if (session.draft && session.draft.type !== 'note' && session.draft.type !== 'text') drawObj(ctx, session.draft);
  drawSelection();
  drawEmptyHint();
  for (const f of overlays) f(ctx, dpr);
  zoomLabel.textContent = Math.round(scale * 100) + '%';
}

// Дополнительные слои поверх доски (курсоры участников и т.п.): fn(ctx, dpr)
const overlays = [];
export function addOverlay(fn) { overlays.push(fn); }

// Мягкая подсказка на совершенно пустой доске (не рисуем, пока открыт home).
function drawEmptyHint() {
  if (state.objects.length || session.draft || session.editing) return;
  if (document.getElementById('home').classList.contains('open')) return;
  const dpr = window.devicePixelRatio || 1;
  ctx.save();
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.fillStyle = '#c9ced6';
  ctx.font = '15px "Segoe UI", system-ui, sans-serif';
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText('Пусто. Выберите инструмент внизу и рисуйте — колесо масштабирует, пробел панорамирует.',
               innerWidth / 2, innerHeight / 2);
  ctx.restore();
}

/* --- сетка: равномерные круглые точки, как в Miro ---
   Шаг в мировых координатах — степень×40; подбирается так,
   чтобы экранный интервал всегда был в [GRID_MIN_PX, GRID_MAX_PX]. */
function drawGrid() {
  const { x, y, scale } = state.view;
  let step = CFG.GRID_BASE;
  while (step * scale < CFG.GRID_MIN_PX) step *= 2;  // слишком часто — ячейку крупнее
  while (step * scale > CFG.GRID_MAX_PX) step /= 2;  // слишком редко — ячейку мельче
  const gap = step * scale;
  const dpr = window.devicePixelRatio || 1;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.fillStyle = CFG.GRID_DOT;
  const r = CFG.GRID_DOT_R;
  const TAU = Math.PI * 2;
  let sx0 = x % gap; if (sx0 > 0) sx0 -= gap;   // первая точка слева/сверху <= 0,
  let sy0 = y % gap; if (sy0 > 0) sy0 -= gap;   // отвязка от мирового начала координат
  ctx.beginPath();
  for (let sx = sx0; sx <= innerWidth + r; sx += gap) {
    for (let sy = sy0; sy <= innerHeight + r; sy += gap) {
      ctx.moveTo(sx + r, sy);
      ctx.arc(sx, sy, r, 0, TAU);
    }
  }
  ctx.fill();
}

/* --- объекты --- */

// Гладкая полилиния: квадратичные кривые через середины отрезков.
export function tracePath(c, pts) {
  c.beginPath();
  if (pts.length < 3) { pts.forEach((p, i) => i ? c.lineTo(p.x, p.y) : c.moveTo(p.x, p.y)); return; }
  c.moveTo(pts[0].x, pts[0].y);
  for (let i = 1; i < pts.length - 1; i++) {
    const mx = (pts[i].x + pts[i + 1].x) / 2, my = (pts[i].y + pts[i + 1].y) / 2;
    c.quadraticCurveTo(pts[i].x, pts[i].y, mx, my);
  }
  c.lineTo(pts[pts.length - 1].x, pts[pts.length - 1].y);
}

export function drawObj(c, o) {
  c.strokeStyle = o.color; c.fillStyle = o.color;
  c.lineWidth = o.width; c.lineCap = 'round'; c.lineJoin = 'round';
  switch (o.type) {
    case 'path': {
      c.save();
      if (o.hl) { c.globalAlpha = CFG.HL_ALPHA; c.globalCompositeOperation = 'multiply'; }
      tracePath(c, o.points);
      c.stroke();
      c.restore();
      break;
    }
    case 'line':
      c.save();
      if (o.dash) c.setLineDash([o.width * 4, o.width * 3]);
      c.beginPath(); c.moveTo(o.x1, o.y1); c.lineTo(o.x2, o.y2); c.stroke();
      c.restore();
      break;
    case 'arrow': {
      c.beginPath(); c.moveTo(o.x1, o.y1); c.lineTo(o.x2, o.y2); c.stroke();
      const a = Math.atan2(o.y2 - o.y1, o.x2 - o.x1), s = Math.max(10, o.width * 3.2);
      c.beginPath();
      c.moveTo(o.x2, o.y2); c.lineTo(o.x2 - s * Math.cos(a - .45), o.y2 - s * Math.sin(a - .45));
      c.moveTo(o.x2, o.y2); c.lineTo(o.x2 - s * Math.cos(a + .45), o.y2 - s * Math.sin(a + .45));
      c.stroke();
      break;
    }
    case 'rect': c.beginPath(); c.roundRect(o.x, o.y, o.w, o.h, 8); c.stroke(); break;
    case 'ellipse': c.beginPath(); c.ellipse(o.x + o.w / 2, o.y + o.h / 2, Math.abs(o.w / 2), Math.abs(o.h / 2), 0, 0, Math.PI * 2); c.stroke(); break;
    case 'note': {
      c.save();
      c.shadowColor = 'rgba(30,40,60,.18)'; c.shadowBlur = 10 / state.view.scale; c.shadowOffsetY = 3 / state.view.scale;
      c.fillStyle = o.fill; c.beginPath(); c.roundRect(o.x, o.y, o.w, o.h, 6); c.fill();
      c.restore();
      if (o.text) drawNoteText(c, o);
      break;
    }
    case 'text': {
      if (!o.text) break;
      c.font = o.fontSize + 'px "Segoe UI", sans-serif'; c.textBaseline = 'top';
      o.text.split('\n').forEach((l, i) => c.fillText(l, o.x, o.y + i * o.fontSize * 1.25));
      break;
    }
  }
}

export function drawNoteText(c, o) {
  c.font = CFG.NOTE_FONT + 'px "Segoe UI", sans-serif';
  c.fillStyle = '#3a3f46'; c.textBaseline = 'top';
  wrapText(o.text, o.w - 24).forEach((l, i) => {
    if (o.y + 14 + (i + 1) * CFG.NOTE_LINE <= o.y + o.h - 6) c.fillText(l, o.x + 12, o.y + 14 + i * CFG.NOTE_LINE);
  });
}

function drawSelection() {
  const sel = state.objects.find(o => o.id === state.selection);
  if (!sel) return;
  const s = state.view.scale;
  ctx.save();
  if (sel.type === 'line' || sel.type === 'arrow' || sel.type === 'path') {
    ctx.strokeStyle = 'rgba(45,108,223,.35)';
    ctx.lineWidth = (sel.width || 3) + 8 / s;
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    if (sel.type === 'path') tracePath(ctx, sel.points);
    else { ctx.beginPath(); ctx.moveTo(sel.x1, sel.y1); ctx.lineTo(sel.x2, sel.y2); }
    ctx.stroke();
    if (sel.type !== 'path') {
      ctx.fillStyle = '#2d6cdf';
      const r = 4 / s;
      for (const q of [{ x: sel.x1, y: sel.y1 }, { x: sel.x2, y: sel.y2 }]) {
        ctx.beginPath(); ctx.arc(q.x, q.y, r, 0, Math.PI * 2); ctx.fill();
      }
    }
  } else {
    const b = bbox(sel), p = 6 / s;
    ctx.strokeStyle = '#2d6cdf'; ctx.lineWidth = 1.5 / s; ctx.setLineDash([5 / s, 4 / s]);
    ctx.strokeRect(b.x - p, b.y - p, b.w + p * 2, b.h + p * 2);
  }
  ctx.restore();
}

/* --- кэш hit-теста для курсора ( троттлинг ) --- */
let lastCursorTest = 0, lastCursorHit = null;
function cursorCacheReset() { lastCursorTest = 0; lastCursorHit = null; }
export function hitTestCached(p) {
  const t = performance.now();
  if (t - lastCursorTest > 60) { lastCursorTest = t; lastCursorHit = findTopAt(p); }
  return lastCursorHit;
}

/* --- миниатюра доски для карточек --- */
export function renderPreview(cv, objects) {
  const dpr = window.devicePixelRatio || 1;
  const W = cv.clientWidth || 220, H = cv.clientHeight || 150;
  cv.width = W * dpr; cv.height = H * dpr;
  const c = cv.getContext('2d');
  c.setTransform(dpr, 0, 0, dpr, 0, 0);
  c.fillStyle = '#fff'; c.fillRect(0, 0, W, H);
  if (!objects.length) {
    c.fillStyle = '#c6ccd4'; c.font = '13px "Segoe UI", sans-serif';
    c.textAlign = 'center'; c.textBaseline = 'middle';
    c.fillText('пустая доска', W / 2, H / 2);
    return;
  }
  const { x1, y1, x2, y2 } = objectsBBox(objects);
  const pad = 10;
  const sc = Math.min((W - pad * 2) / Math.max(x2 - x1, 1), (H - pad * 2) / Math.max(y2 - y1, 1), 1);
  const ox = pad + (W - pad * 2 - (x2 - x1) * sc) / 2 - x1 * sc;
  const oy = pad + (H - pad * 2 - (y2 - y1) * sc) / 2 - y1 * sc;
  c.setTransform(dpr * sc, 0, 0, dpr * sc, dpr * ox, dpr * oy);
  const oldScale = state.view.scale; state.view.scale = sc;
  for (const o of objects) drawObj(c, o);
  state.view.scale = oldScale;
}
