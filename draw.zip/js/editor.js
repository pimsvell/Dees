import { CFG } from './config.js';
import { state, session } from './state.js';
import { pushHistory } from './history.js';
import { render } from './render.js';

// Встроенный textarea для редактирования текста заметок и надписей.

const editor = document.getElementById('editor');

export function openEditor(o) {
  session.editing = o;
  const isNote = o.type === 'note';
  const sx = o.x * state.view.scale + state.view.x;
  const sy = (isNote ? o.y + 10 : o.y) * state.view.scale + state.view.y;
  editor.style.display = 'block';
  editor.style.left = sx + 'px';
  editor.style.top = sy + 'px';
  editor.style.width = (isNote ? (o.w - 24) * state.view.scale : Math.max(120, 200 * state.view.scale)) + 'px';
  editor.style.minHeight = isNote ? (o.h - 22) * state.view.scale + 'px' : 'auto';
  editor.style.color = isNote ? '#3a3f46' : o.color;
  editor.style.fontSize = (isNote ? CFG.NOTE_FONT : o.fontSize) * state.view.scale + 'px';
  editor.style.lineHeight = isNote ? (CFG.NOTE_LINE / CFG.NOTE_FONT) : 1.25;
  editor.value = o.text || '';
  editor.focus();
  render();
}

export function commitEditor() {
  const o = session.editing;
  if (!o) return;
  o.text = editor.value;
  if ((o.type === 'text' || o.type === 'note') && !editor.value.trim()) {
    state.objects = state.objects.filter(x => x.id !== o.id); // пустые — не сохраняем
    if (state.selection === o.id) state.selection = null;
  }
  pushHistory();
  session.editing = null;
  editor.style.display = 'none';
  render();
}

editor.addEventListener('keydown', e => {
  e.stopPropagation();
  if (e.key === 'Escape' || (e.key === 'Enter' && (e.ctrlKey || e.metaKey))) editor.blur();
});
editor.addEventListener('blur', commitEditor);
export { editor };
