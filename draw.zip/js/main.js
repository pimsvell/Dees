import { Store, saveNow } from './store.js';
import { state, session } from './state.js';
import { CFG } from './config.js';
import { historyReset, undo, redo } from './history.js';
import { resize, renderNow, render } from './render.js';
import { bindCanvasInput } from './tools.js';
import { bindPanels, bindKeys, showBoardChrome } from './panels.js';
import { openHome, renderBoardBar, importBoard, renderHome } from './home.js';
import { buildBoardPDFBlob, renderBoardCanvas } from './exporter.js';
import { serializeBoard } from './files.js';
import { readShareFromUrl, buildShareLink } from './share.js';
import { rt, rtJoin, rtHost, stopLive, cursorAt } from './rt.js';
import { syncWithFolder, syncInfo, syncAutoStart, syncStatusLine, syncNewBoard, removeBoardFile } from './sync.js';
import { setStatus } from './utils.js';

// Точка входа: загрузка хранилища, обработка приглашения по ссылке, старт UI.

Store.load();

const invite = await readShareFromUrl();   // { name, objects, view, role } | null
// участнику убираем #share= (доска уже импортирована), гостю оставляем, чтобы F5 сохранил просмотр
if (invite && invite.role !== 'guest') history.replaceState(null, '', location.pathname + location.search);

if (invite) {
  state.objects = invite.objects;
  state.view = Object.assign({ x: 0, y: 0, scale: 1 }, invite.view);
  if (invite.role === 'guest') {
    state.readonly = true;                 // гость: временный просмотр, не сохраняем
    document.getElementById('curBoardName').textContent = invite.name;
  } else {                                 // участник: своя редактируемая копия
    const b = importBoard({ name: invite.name + ' (общая)', objects: invite.objects, view: invite.view });
    Store.setActive(b.id);
    state.objects = JSON.parse(JSON.stringify(b.objects));
    state.view = Object.assign({ x: 0, y: 0, scale: 1 }, b.view);
    renderBoardBar();
  }
  state.selection = null;
  historyReset();
} else if (rt.room) {
  await rtJoin().catch(() => {});        // realtime: живая доска (сервер или P2P)
  state.selection = null;
  historyReset();
} else {
  const cur = Store.board();
  if (cur) {
    state.objects = JSON.parse(JSON.stringify(cur.objects || []));
    state.view = Object.assign({ x: 0, y: 0, scale: 1 }, cur.view);
  } else {
    state.objects = [];
  }
  state.selection = null;
  historyReset();
  renderBoardBar();
}

bindCanvasInput();
bindPanels();
bindKeys();
addEventListener('resize', resize);
resize();
renderNow();

if (invite) showBoardChrome(invite.role);
else if (rt.room) showBoardChrome(rt.role);
else openHome();
// приглашённый по ссылке (live-гость/участник или гость-снимок): без «Поделиться» и без чужих досок
if (rt.room || (invite && invite.role === 'guest')) document.body.classList.add('invited');

// Крюк для отладки и автотестов (не используется интерфейсом).
window.boardApp = { state, session, Store, CFG, saveNow, undo, redo, render, renderNow, resize,
                    buildBoardPDFBlob, renderBoardCanvas, serializeBoard, buildShareLink, readShareFromUrl,
                    rt, rtJoin, rtHost, stopLive, cursorAt, syncWithFolder, syncInfo, syncNewBoard, removeBoardFile };

// Локальная папка — основное хранилище: при первом дейтии молча дозагружаем,
// если браузер уже знает эту папку и право доступа сохранилось.
syncAutoStart(r => {
  setStatus('Папка «' + r.dirName + '»: привезено ' + r.imported + ', обновлено ' + r.updated + ', сохранено ' + r.exported);
  if (document.getElementById('home').classList.contains('open')) renderHome();
  syncStatusLine();
});
