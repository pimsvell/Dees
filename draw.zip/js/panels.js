import { CFG } from './config.js';
import { state, session } from './state.js';
import { undo, redo, pushHistory } from './history.js';
import { render, canvas } from './render.js';
import { toWorld } from './utils.js';
import { findTopAt } from './scene.js';
import {
  TOOL_KEYS, setTool, setColor, setWidth, zoomAt, selectedObject, moveObject,
  deleteSelection, duplicateSelected, clearBoard,
  copySelection, pasteClipboard, hasClipboard, reorder, fitToContent,
} from './tools.js';
import { exportCurrentPNG, exportCurrentPDF } from './exporter.js';
import { saveBoardToFile } from './files.js';
import { Store } from './store.js';
import {
  openHome, addBoard, addFolder, openBoardFileFromDisk, renameBoard, importBoard, switchBoard, closeHome, renderHome,
} from './home.js';
import { homeSyncClick, syncStatusLine } from './sync.js';
import { buildShareLink } from './share.js';
import { rt, rtHost, rtPublicBase, stopLive } from './rt.js';

// Привязка панелей, выпадающих и контекстного меню, горячих клавиш.

const ctxMenu = document.getElementById('ctxmenu');

function closeMenus() {
  document.querySelectorAll('.menu-open').forEach(m => m.classList.remove('menu-open'));
}
function closeCtx() { ctxMenu.classList.remove('show'); }

function toggleMenu(wrap) {
  const was = wrap.classList.contains('menu-open');
  closeMenus(); closeCtx();
  if (!was) wrap.classList.add('menu-open');
}

function openCtx(x, y, onObject) {
  const ro = state.readonly;
  ctxMenu.querySelectorAll('.obj-only').forEach(b => { b.style.display = onObject && !ro ? '' : 'none'; });
  ctxMenu.querySelector('[data-ctx=paste]').style.display = hasClipboard() && !ro ? '' : 'none';
  const sep = ctxMenu.querySelector('.ctx-sep');
  sep.style.display = !ro && (onObject || hasClipboard()) ? '' : 'none';
  ctxMenu.classList.add('show');
  const r = ctxMenu.getBoundingClientRect();
  ctxMenu.style.left = Math.min(x, innerWidth - r.width - 8) + 'px';
  ctxMenu.style.top = Math.min(y, innerHeight - r.height - 8) + 'px';
}

export function bindPanels() {
  document.querySelectorAll('.tool').forEach(b => b.onclick = () => setTool(b.dataset.tool));
  document.querySelectorAll('.toolgroup .menu-item').forEach(mi => mi.onclick = () => {
    setTool(mi.dataset.tool); closeMenus();
  });
  document.querySelectorAll('.tcaret').forEach(c => c.onclick = e => {
    e.stopPropagation(); toggleMenu(c.closest('.toolgroup'));
  });

  document.querySelectorAll('.swatch').forEach(s => s.onclick = () => {
    document.querySelectorAll('.swatch').forEach(x => x.classList.remove('active'));
    s.classList.add('active');
    setColor(s.dataset.color);
  });
  document.getElementById('customColor').oninput = e => {
    document.querySelectorAll('.swatch').forEach(x => x.classList.remove('active'));
    setColor(e.target.value);
  };
  document.getElementById('widthRange').oninput = e => setWidth(+e.target.value);

  document.getElementById('undoBtn').onclick = undo;
  document.getElementById('redoBtn').onclick = redo;
  document.getElementById('delBtn').onclick = deleteSelection;
  document.getElementById('clearBtn').onclick = clearBoard;

  const expDrop = document.getElementById('exportDrop');
  document.getElementById('exportBtn').onclick = e => { e.stopPropagation(); toggleMenu(expDrop); };
  document.querySelectorAll('[data-export]').forEach(b => b.onclick = () => {
    closeMenus();
    if (b.dataset.export === 'png') exportCurrentPNG();
    else if (b.dataset.export === 'pdf') exportCurrentPDF();
    else if (b.dataset.export === 'share') openShareModal();
    else { const bd = Store.board(); if (bd) saveBoardToFile(bd); }
  });

  document.getElementById('zoomIn').onclick = () => zoomAt(innerWidth / 2, innerHeight / 2, CFG.ZOOM_STEP);
  document.getElementById('zoomOut').onclick = () => zoomAt(innerWidth / 2, innerHeight / 2, 1 / CFG.ZOOM_STEP);
  document.getElementById('zoomReset').onclick = () => { state.view = { x: 0, y: 0, scale: 1 }; render(); };
  document.getElementById('fitBtn').onclick = fitToContent;

  document.getElementById('boardBtn').onclick = openHome;
  document.getElementById('renameCurBoard').onclick = () => {
    const b = Store.board(); if (b) renameBoard(b);
  };
  document.getElementById('addBoardBtn').onclick = addBoard;
  document.getElementById('homeNew').onclick = addBoard;
  document.getElementById('homeNewFolder').onclick = addFolder;
  document.getElementById('homeOpenFile').onclick = openBoardFileFromDisk;
  const syncBtn = document.getElementById('homeSync');
  if (syncBtn) syncBtn.onclick = async ev => {
    try { const r = await homeSyncClick(ev.currentTarget); if (r) renderHome(); } catch (e) { /* текст уже в статусе */ }
    syncStatusLine();
  };

  // --- контекстное меню холста ---
  canvas.addEventListener('contextmenu', e => {
    e.preventDefault();
    if (session.editing) return;
    const o = findTopAt(toWorld(e.clientX, e.clientY));
    if (o) { state.selection = o.id; render(); }
    openCtx(e.clientX, e.clientY, !!o);
  });
  ctxMenu.querySelectorAll('[data-ctx]').forEach(b => b.onclick = () => {
    closeCtx();
    if (state.readonly && b.dataset.ctx !== 'fit') return;
    ({
      dup: duplicateSelected, front: () => reorder(1), back: () => reorder(-1),
      del: deleteSelection, paste: pasteClipboard, fit: fitToContent,
    })[b.dataset.ctx]();
  });

  // клик мимо любого открытого меню закрывает его
  addEventListener('pointerdown', e => {
    if (!e.target.closest('.menu-open') && !e.target.closest('#ctxmenu') && !e.target.closest('.modal')) { closeMenus(); closeCtx(); }
  }, true);

  initShareUI();
}

export function bindKeys() {
  addEventListener('keydown', e => {
    if (e.target.id === 'editor' || document.getElementById('home').classList.contains('open')) return;
    if (e.code === 'Space' && !session.spaceDown) { session.spaceDown = true; render(); e.preventDefault(); return; }
    if (state.readonly) return;          // гость: только пан пробелом и навигация
    const mod = e.ctrlKey || e.metaKey;
    const k = e.key.toLowerCase();
    if (mod && k === 'z' && !e.shiftKey) { e.preventDefault(); undo(); }
    else if (mod && (k === 'y' || (k === 'z' && e.shiftKey))) { e.preventDefault(); redo(); }
    else if (mod && k === 'd') { e.preventDefault(); duplicateSelected(); }
    else if (mod && k === 'c') { e.preventDefault(); copySelection(); }
    else if (mod && k === 'v') { e.preventDefault(); pasteClipboard(); }
    else if (e.key.startsWith('Arrow') && state.selection) {
      const o = selectedObject();
      if (o) {
        e.preventDefault();
        const d = e.shiftKey ? 10 : 1;
        moveObject(o, (e.key === 'ArrowLeft' ? -d : e.key === 'ArrowRight' ? d : 0),
                      (e.key === 'ArrowUp' ? -d : e.key === 'ArrowDown' ? d : 0));
        pushHistory(); render();
      }
    }
    else if (e.key === 'Delete' || e.key === 'Backspace') deleteSelection();
    else if (e.key === 'Escape') {
      closeMenus(); closeCtx();
      session.draft = null; session.drag = null; // отмена незавершённого штриха
      state.selection = null; render();
    }
    else if (!mod && TOOL_KEYS[e.code]) setTool(TOOL_KEYS[e.code]);
  });
  addEventListener('keyup', e => { if (e.code === 'Space') session.spaceDown = false; });
}

/* --- приглашение по ссылке (панель в правом верхнем углу) --- */
const sharePop = document.getElementById('sharePop');

function snapshotData() {
  const b = Store.board();
  return {
    name: (b && b.name) || (document.getElementById('curBoardName') || {}).textContent || 'Доска',
    objects: state.objects,
    view: state.view,
  };
}

async function refreshShareLink() {
  const linkEl = document.getElementById('shareLink');
  const tip = document.getElementById('shareTip');
  const roleEl = document.querySelector('input[name="shareRole"]:checked');
  const role = roleEl ? roleEl.value : 'guest';
  const liveBox = document.getElementById('shareLive');
  const b = Store.board();
  const idEl = document.getElementById('shareBoardId');
  if (idEl) idEl.textContent = (b && b.id) || '—';
  linkEl.value = 'Готовим ссылку…'; tip.textContent = ''; tip.className = 'modal-tip';
  const bId = b ? String(b.id).replace(/[^A-Za-z0-9_-]/g, '-').slice(0, 40) : null;
  if (liveBox && liveBox.checked && state.readonly) {
    linkEl.value = '';
    tip.textContent = 'Гость не может приглашать дальше — сохраните копию доски.';
    tip.className = 'modal-tip err';
    return;
  }
  if (liveBox && liveBox.checked && bId && bId.length >= 4) {
    try {
      await rtHost(bId);                 // комната = ID доски; транспорт: сервер или P2P
      const base = rt.mode === 'peer' ? location.origin : rtPublicBase();
      linkEl.value = base + location.pathname + '?room=' + bId + '&role=' + (role === 'guest' ? 'g' : 'p');
      tip.textContent = (rt.mode === 'peer' ? 'P2P-режим (без сервера): ваша вкладка и есть сервер. ' : '')
        + (role === 'guest'
          ? 'Живой просмотр: все изменения доски гость видит через секунду.'
          : 'Участник видит доску живьём и может рисовать — вы это сразу увидите.');
      tip.className = 'modal-tip ok';
      return;
    } catch (e) {
      tip.textContent = 'Realtime недоступен (' + (e && e.message ? e.message : e) + ') — даю ссылку-снимок.';
      tip.className = 'modal-tip err';  // ниже строим снимок, ссылка будет в любом случае
    }
  }
  try {
    linkEl.value = await buildShareLink(snapshotData(), role === 'guest' ? 'g' : 'p');
    if (tip.className !== 'modal-tip err') {
      const kb = Math.max(1, Math.round(linkEl.value.length / 1024));
      tip.textContent = (role === 'guest'
        ? 'Снимок доски в ссылке: гость откроет копию в режиме только просмотр. '
        : 'Снимок доски в ссылке: участник откроет свою копию и сможет редактировать. ')
        + `Размер ссылки: ~${kb} КБ.`;
      tip.className = 'modal-tip ok';
    }
  } catch (e) {
    linkEl.value = '';
    tip.textContent = e && e.message === 'too_big'
      ? 'Доска слишком большая для ссылки — используйте экспорт в файл.'
      : 'Не удалось построить ссылку: ' + (e && e.message ? e.message : e);
    tip.className = 'modal-tip err';
  }
}

function openShareModal() {
  if (document.body.classList.contains('invited')) return;
  sharePop.classList.add('open');
  refreshShareLink();
}

function initShareUI() {
  const close = () => sharePop.classList.remove('open');
  document.getElementById('shareBtnTop').onclick = openShareModal;
  document.getElementById('shareClose').onclick = close;
  document.addEventListener('home-open', close);
  addEventListener('pointerdown', e => {
    if (!sharePop.classList.contains('open')) return;
    if (sharePop.contains(e.target)) return;
    if (e.target.closest('#shareBtnTop, #livepill, [data-export="share"]')) return;
    close();
  }, true);
  document.querySelectorAll('input[name="shareRole"]').forEach(r => r.onchange = refreshShareLink);
  const liveBox = document.getElementById('shareLive');
  if (liveBox) liveBox.onchange = refreshShareLink;
  const pill = document.getElementById('livepill');
  if (pill) pill.onclick = openShareModal;
  document.getElementById('shareCopy').onclick = async () => {
    const linkEl = document.getElementById('shareLink');
    const tip = document.getElementById('shareTip');
    if (!linkEl.value) return;
    try { await navigator.clipboard.writeText(linkEl.value); }
    catch (e) { linkEl.select(); document.execCommand('copy'); }
    tip.textContent = 'Ссылка скопирована в буфер обмена.';
    tip.className = 'modal-tip ok';
  };
  addEventListener('keydown', e => { if (e.key === 'Escape') close(); });
}

/* --- показ открытой доски после входа по ссылке-приглашению --- */
export function showBoardChrome(role) {
  document.body.classList.toggle('readonly', state.readonly);
  document.getElementById('saveCopyBtn').onclick = () => {
    stopLive();                       // гость остался со своей копией — трансляция ему больше не нужна
    const name = (document.getElementById('curBoardName').textContent || 'Доска').trim();
    const b = importBoard({ name: name + ' (копия)', objects: state.objects, view: state.view });
    switchBoard(b.id);
    state.readonly = false;
    document.body.classList.remove('readonly', 'invited');   // сохранённая копия — своя доска
    closeHome();
  };
  // участник (role !== 'guest') ничего не требует: доска уже импортирована и редактируется
}
