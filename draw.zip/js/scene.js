import { state } from './state.js';
import { CFG } from './config.js';
import { clamp, dist } from './utils.js';

// Геометрия объектов, hit-тест и сглаживание штрихов.
//
// Объекты:
//   path   {points:[{x,y}], width, color, hl?}
//   line   {x1,y1,x2,y2, width, color, dash?}
//   arrow  {x1,y1,x2,y2, width, color}
//   rect/ellipse {x,y,w,h, width, color}
//   note   {x,y,w,h, fill, text}
//   text   {x,y,fontSize,color,text}

// Отдельный контекст только для замеров текста.
const meas = document.createElement('canvas').getContext('2d');

export function bbox(o) {
  switch (o.type) {
    case 'path': {
      let x1 = Infinity, y1 = Infinity, x2 = -Infinity, y2 = -Infinity;
      for (const p of o.points) { x1 = Math.min(x1, p.x); y1 = Math.min(y1, p.y); x2 = Math.max(x2, p.x); y2 = Math.max(y2, p.y); }
      const m = o.width / 2 + 2;
      return { x: x1 - m, y: y1 - m, w: x2 - x1 + m * 2, h: y2 - y1 + m * 2 };
    }
    case 'line': case 'arrow':
      return { x: Math.min(o.x1, o.x2) - 6, y: Math.min(o.y1, o.y2) - 6, w: Math.abs(o.x2 - o.x1) + 12, h: Math.abs(o.y2 - o.y1) + 12 };
    case 'rect': case 'ellipse': case 'note':
      return { x: o.x, y: o.y, w: o.w, h: o.h };
    case 'text': {
      meas.font = o.fontSize + 'px "Segoe UI", sans-serif';
      const lines = (o.text || ' ').split('\n');
      return { x: o.x, y: o.y, w: Math.max(...lines.map(l => meas.measureText(l || ' ').width), 10), h: lines.length * o.fontSize * 1.25 };
    }
  }
}

export function objectsBBox(objects) {
  let x1 = Infinity, y1 = Infinity, x2 = -Infinity, y2 = -Infinity;
  for (const o of objects) {
    const b = bbox(o);
    if (!b) continue;
    x1 = Math.min(x1, b.x); y1 = Math.min(y1, b.y); x2 = Math.max(x2, b.x + b.w); y2 = Math.max(y2, b.y + b.h);
  }
  return { x1, y1, x2, y2 };
}

export function distToSegment(p, a, b) {
  const l2 = (a.x - b.x) ** 2 + (a.y - b.y) ** 2;
  if (l2 === 0) return dist(p, a);
  const t = clamp(((p.x - a.x) * (b.x - a.x) + (p.y - a.y) * (b.y - a.y)) / l2, 0, 1);
  return dist(p, { x: a.x + t * (b.x - a.x), y: a.y + t * (b.y - a.y) });
}

export function hit(o, p) {
  const tol = 7 / state.view.scale;
  switch (o.type) {
    case 'path': return o.points.some((q, i) => i > 0 && distToSegment(p, o.points[i - 1], q) < tol + o.width / 2);
    case 'line': case 'arrow': return distToSegment(p, { x: o.x1, y: o.y1 }, { x: o.x2, y: o.y2 }) < tol + o.width / 2;
    case 'rect': case 'ellipse': case 'note':
      return p.x >= o.x - tol && p.x <= o.x + o.w + tol && p.y >= o.y - tol && p.y <= o.y + o.h + tol;
    case 'text': {
      const b = bbox(o);
      return p.x >= b.x - 4 && p.x <= b.x + b.w + 4 && p.y >= b.y - 4 && p.y <= b.y + b.h + 4;
    }
  }
  return false;
}

// Верхний объект под точкой; быстрый отказ по bbox.
export function findTopAt(p) {
  const tol = 10 / state.view.scale;
  for (let i = state.objects.length - 1; i >= 0; i--) {
    const o = state.objects[i], b = bbox(o);
    if (!b) continue;
    if (p.x < b.x - tol || p.x > b.x + b.w + tol || p.y < b.y - tol || p.y > b.y + b.h + tol) continue;
    if (hit(o, p)) return o;
  }
  return null;
}

/* --- сглаживание штрихов --- */

// Упрощение полилинии (Ramer–Douglas–Peucker).
export function rdp(pts, eps) {
  if (pts.length < 3) return pts;
  const keep = new Uint8Array(pts.length);
  keep[0] = keep[pts.length - 1] = 1;
  const stack = [[0, pts.length - 1]];
  const eps2 = eps * eps;
  while (stack.length) {
    const [a, b] = stack.pop();
    const ax = pts[a].x, ay = pts[a].y, dx = pts[b].x - ax, dy = pts[b].y - ay, l2 = dx * dx + dy * dy;
    let maxd = -1, idx = -1;
    for (let i = a + 1; i < b; i++) {
      const t = clamp(l2 ? ((pts[i].x - ax) * dx + (pts[i].y - ay) * dy) / l2 : 0, 0, 1);
      const ex = pts[i].x - (ax + t * dx), ey = pts[i].y - (ay + t * dy);
      const d = ex * ex + ey * ey;
      if (d > maxd) { maxd = d; idx = i; }
    }
    if (maxd > eps2 && idx > a) { keep[idx] = 1; stack.push([a, idx], [idx, b]); }
  }
  return pts.filter((p, i) => keep[i]);
}

// Срезание углов (Chaikin).
export function chaikin(pts, iters) {
  let out = pts;
  for (let k = 0; k < iters; k++) {
    if (out.length < 3) return out.map(p => ({ ...p }));
    const np = [out[0]];
    for (let i = 0; i < out.length - 1; i++) {
      const p = out[i], q = out[i + 1];
      if (i > 0) np.push({ x: p.x * 0.75 + q.x * 0.25, y: p.y * 0.75 + q.y * 0.25 });
      np.push({ x: p.x * 0.25 + q.x * 0.75, y: p.y * 0.25 + q.y * 0.75 });
    }
    np.push(out[out.length - 1]);
    out = np;
  }
  return out;
}

export const smoothStroke = raw => chaikin(rdp(raw, CFG.RDP_EPS), CFG.CHAIKIN_ITERS);

// Перенос текста по словам (для заметок).
export function wrapText(text, maxW) {
  meas.font = CFG.NOTE_FONT + 'px "Segoe UI", sans-serif';
  const out = [];
  for (const raw of text.split('\n')) {
    let line = '';
    for (const word of raw.split(' ')) {
      const test = line ? line + ' ' + word : word;
      if (meas.measureText(test).width > maxW && line) { out.push(line); line = word; }
      else line = test;
    }
    out.push(line);
  }
  return out;
}
