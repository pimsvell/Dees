import { CFG } from './config.js';
import { state } from './state.js';
import { save } from './store.js';
import { render } from './render.js';

// Снимки состояния объектов: undo/redo + автосохранение при изменении.

const history = { stack: [], idx: -1 };

export function historyReset() {
  history.stack = [JSON.stringify(state.objects)];
  history.idx = 0;
  historySyncUI();
}

export function pushHistory() {
  history.stack = history.stack.slice(0, history.idx + 1);
  history.stack.push(JSON.stringify(state.objects));
  if (history.stack.length > CFG.HISTORY_MAX) history.stack.shift();
  history.idx = history.stack.length - 1;
  historySyncUI();
  save();
}

export function undo() { if (history.idx > 0) historyApply(history.idx - 1); }
export function redo() { if (history.idx < history.stack.length - 1) historyApply(history.idx + 1); }

function historyApply(i) {
  history.idx = i;
  state.objects = JSON.parse(history.stack[i]);
  state.selection = null;
  historySyncUI();
  save();
  render();
}

function historySyncUI() {
  document.getElementById('undoBtn').disabled = history.idx <= 0;
  document.getElementById('redoBtn').disabled = history.idx >= history.stack.length - 1;
}
