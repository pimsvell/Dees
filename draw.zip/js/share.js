import { CFG } from './config.js';

// Приглашение по ссылке: доска упаковывается прямо в URL (deflate + base64url).
// role=g — получатель открывает её как гость (только просмотр),
// иначе — как участник (просмотр и редактирование своей копии).

function b64urlEncode(bytes) {
  let bin = '';
  for (let i = 0; i < bytes.length; i += 0x8000)
    bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function b64urlDecode(s) {
  const b64 = s.replace(/-/g, '+').replace(/_/g, '/') + '='.repeat((4 - s.length % 4) % 4);
  const bin = atob(b64);
  const u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return u8;
}

async function deflate(bytes) {
  const stream = new Blob([bytes]).stream().pipeThrough(new CompressionStream('deflate-raw'));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

async function inflate(bytes) {
  const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
  return await new Response(stream).text();
}

const MAX_LEN = 1_900_000; // запас под лимиты URL в браузерах

// data = { name, objects, view } — обычно текущее открытое состояние доски.
// Возвращает готовую ссылку; бросает Error('too_big') если URL не помещается.
export async function buildShareLink(data, role) {
  if (!data || !Array.isArray(data.objects)) throw new Error('no data');
  const json = JSON.stringify({ app: CFG.APP_ID, v: 1, name: data.name || 'Доска',
                                objects: data.objects, view: data.view });
  let payload;
  if (typeof CompressionStream === 'function') {
    payload = 'z' + b64urlEncode(await deflate(new TextEncoder().encode(json)));
  } else { // запасной путь без сжатия
    payload = 'r' + b64urlEncode(new TextEncoder().encode(json));
  }
  const url = location.origin + location.pathname + '#share=' + payload + (role === 'g' ? '&role=g' : '');
  if (url.length > MAX_LEN) throw new Error('too_big');
  return url;
}

// Читает приглашение из #share=... Возвращает {name,objects,view,role} или null.
export async function readShareFromUrl() {
  if (!location.hash.startsWith('#share=')) return null;
  const q = new URLSearchParams(location.hash.slice(1));
  const data = q.get('share');
  if (!data || data.length < 2) return null;
  try {
    const body = b64urlDecode(data.slice(1));
    const json = data[0] === 'z' ? await inflate(body) : new TextDecoder().decode(body);
    const d = JSON.parse(json);
    if (!Array.isArray(d.objects)) return null;
    return {
      name: String(d.name || 'Доска').slice(0, 60),
      objects: d.objects,
      view: d.view && d.view.scale ? d.view : null,
      role: q.get('role') === 'g' ? 'guest' : null,
    };
  } catch (e) { return null; }
}
