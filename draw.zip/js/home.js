import { state, session } from './state.js';
import { plural, uid } from './utils.js';
import { Store, saveNow } from './store.js';
import { historyReset } from './history.js';
import { render, renderPreview } from './render.js';
import { commitEditor } from './editor.js';
import { saveBoardToFile, readBoardFile } from './files.js';
import { exportBoardPNG, exportBoardPDF } from './exporter.js';
import { rt, stopLive } from './rt.js';
import { syncInfo, syncWithFolder, syncNewBoard, removeBoardFile, syncRename, syncFolderRenamed, syncFolderCleared } from './sync.js';

let syncOffered = false;   // предложение выбрать папку — не чаще раза за сеанс

// Стартовая страница: карточки досок и папок, переключение досок.

const homeEl = document.getElementById('home');
// флаг «главная открыта» для CSS (кнопка «Поделиться» и пр. только над доской)
const syncHomeFlag = () => {
  const on = homeEl.classList.contains('open');
  document.body.classList.toggle('home-open', on);
  if (on) document.dispatchEvent(new Event('home-open'));
};
new MutationObserver(syncHomeFlag).observe(homeEl, { attributes: true, attributeFilter: ['class'] });
syncHomeFlag();
const boardGrid = document.getElementById('boardGrid');

const ICONS = {
  pen:   '<svg viewBox="0 0 24 24"><path d="M4 20l1-4L17 4l3 3L8 19zM14 7l3 3"/></svg>',
  copy:  '<svg viewBox="0 0 24 24"><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 00-2-2H6a2 2 0 00-2 2v8a2 2 0 002 2h2"/></svg>',
  png:   '<svg viewBox="0 0 24 24"><path d="M12 4v11M8 11l4 4 4-4M4 19h16"/></svg>',
  pdf:   '<svg viewBox="0 0 24 24"><path d="M6 2h8l4 4v16H6zM14 2v4h4M9 13h6M9 17h6"/></svg>',
  save:  '<svg viewBox="0 0 24 24"><path d="M5 3h11l3 3v15H5zM8 3v6h7V3M8 21v-7h8v7"/></svg>',
  trash: '<svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/></svg>',
};

function cbtn(icon, title, fn) {
  const b = document.createElement('button');
  b.className = 'cbtn';
  b.innerHTML = icon + '<span class="hint">' + title + '</span>';
  b.onclick = e => { e.stopPropagation(); fn(); };
  return b;
}

/* --- переключение вида --- */
export function openHome() {
  if (document.body.classList.contains('invited')) return;   // приглашённый не уходит к чужим доскам
  commitEditor(); saveNow(); homeEl.classList.add('open'); renderHome();
}
export function closeHome() { homeEl.classList.remove('open'); session.homeFolder = null; }
export function homeIsOpen() { return homeEl.classList.contains('open'); }

/* --- работа с досками --- */
export function renderBoardBar() {
  const cur = Store.board();
  document.getElementById('curBoardName').textContent = cur ? cur.name : '—';
}

export function openBoardIntoState(b) {
  if (rt.room) stopLive();             // открыли свою локальную доску — live-сессия сворачивается
  state.objects = JSON.parse(JSON.stringify(b.objects || []));
  state.view = Object.assign({ x: 0, y: 0, scale: 1 }, b.view);
  state.selection = null;
  state.readonly = false;                // своя сохранённая доска всегда редактируема
  document.body.classList.remove('readonly', 'invited');
  historyReset();
  render();
}

export function switchBoard(id) {
  commitEditor();
  if (id === Store.raw().active) return;
  Store.setActive(id);
  const b = Store.board();
  if (b) openBoardIntoState(b);
  renderBoardBar();
}

export async function addBoard() {
  commitEditor();
  if (!syncInfo() && !syncOffered) {
    syncOffered = true;
    if (confirm('Хотите хранить доски в обычной папке на компьютере? «OK» — выбрать папку сейчас, новая доска сразу сохранится в неё.')) {
      try { await syncWithFolder(); renderHome(); } catch (e) { /* отмена — доска будет только в браузере */ }
    }
  }
  const name = prompt('Название доски:', 'Доска ' + (Store.raw().list.length + 1));
  if (name === null || !name.trim()) return;
  const b = Store.addBoard(name.trim(), session.homeFolder);
  syncNewBoard(b);
  renderHome();
}

export async function renameBoard(b) {
  const name = prompt('Новое название:', b.name);
  if (name === null || !name.trim()) return;
  b.name = name.trim();
  Store.persist();
  await syncRename(b);
  renderBoardBar(); renderHome();
}

export function duplicateBoard(b) {
  saveNow();
  const c = JSON.parse(JSON.stringify(b));
  c.id = uid(); c.name = b.name + ' (копия)'; c.updated = Date.now();
  Store.raw().list.splice(Store.raw().list.indexOf(b) + 1, 0, c);
  Store.persist(); renderHome();
}

export function deleteBoard(b) {
  if (!confirm('Удалить доску «' + b.name + '»?')) return;
  const wasActive = Store.raw().active === b.id;
  Store.removeBoard(b);
  removeBoardFile(b);
  if (wasActive) {
    const next = Store.board();
    if (next) openBoardIntoState(next);
    else {
      state.objects = []; state.selection = null; historyReset(); render();
    }
  }
  renderBoardBar(); renderHome();
}

/* --- папки --- */
export function addFolder() {
  const name = prompt('Название папки:', 'Папка ' + (Store.folders().length + 1));
  if (name === null || !name.trim()) return;
  Store.addFolder(name.trim());
  renderHome();
}
export async function renameFolder(f) {
  const name = prompt('Новое название папки:', f.name);
  if (name === null || !name.trim()) return;
  const prev = f.name;
  f.name = name.trim();
  Store.persist(); renderHome();
  await syncFolderRenamed(f.id, prev);
}
export async function deleteFolder(f) {
  if (!confirm('Удалить папку «' + f.name + '»? Доски из неё переедут в «Мои доски».')) return;
  const ids = Store.raw().list.filter(b => b.folder === f.id).map(b => b.id);
  const prev = f.name;
  Store.removeFolder(f);
  renderHome();
  await syncFolderCleared(ids, prev);
}
function dropBoard(e, folderId) {
  e.preventDefault();
  const id = e.dataTransfer.getData('text/plain');
  const b = Store.raw().list.find(x => x.id === id);
  if (b && (b.folder || null) !== folderId) { b.folder = folderId; Store.persist(); }
  renderHome();
}

/* --- открытие файла доски --- */
export async function openBoardFileFromDisk() {
  try {
    const d = await readBoardFile();
    if (!d) return;
    const b = importBoard(d);
    switchBoard(b.id);
    closeHome();
  } catch (e) { alert('Не удалось прочитать файл доски'); }
}

// Создаёт новую доску из { name, objects, view }, сохраняет и возвращает её.
export function importBoard(d) {
  const b = Store.addBoard(d.name || 'Доска', session.homeFolder);
  b.objects = d.objects || [];
  if (d.view) b.view = d.view;
  Store.persist();
  return b;
}

/* --- отрисовка стартовой --- */
function makeCard(titleText, headEl, metaText, actions, onClick) {
  const card = document.createElement('div');
  card.className = 'card';
  card.onclick = onClick;
  const body = document.createElement('div'); body.className = 'cbody';
  const nm = document.createElement('div'); nm.className = 'cname';
  nm.append(document.createTextNode(titleText));
  const meta = document.createElement('div'); meta.className = 'cmeta';
  meta.textContent = metaText;
  const acts = document.createElement('div'); acts.className = 'cactions';
  actions.forEach(a => acts.append(cbtn(a[0], a[1], a[2])));
  body.append(nm, meta, acts);
  card.append(headEl, body);
  return { card, nm };
}

function makeBoardCard(b) {
  const cv = document.createElement('canvas');
  cv.className = 'preview';
  const n = (b.objects || []).length;
  const meta = new Date(b.updated || Date.now()).toLocaleDateString() + ' · ' + n + ' ' + plural(n, 'объект', 'объекта', 'объектов');
  const { card, nm } = makeCard(b.name, cv, meta, [
    [ICONS.pen, 'Переименовать', () => renameBoard(b)],
    [ICONS.copy, 'Дублировать', () => duplicateBoard(b)],
    [ICONS.png, 'Экспорт PNG', () => exportBoardPNG(b)],
    [ICONS.pdf, 'Экспорт PDF', () => exportBoardPDF(b)],
    [ICONS.save, 'Сохранить в файл', () => saveBoardToFile(b)],
    [ICONS.trash, 'Удалить', () => deleteBoard(b)],
  ], () => { switchBoard(b.id); closeHome(); });
  if (b.id === Store.raw().active) {
    const t = document.createElement('span'); t.className = 'now'; t.textContent = 'открыта';
    nm.appendChild(t);
    card.classList.add('active');
  }
  card.draggable = true;
  card.ondragstart = e => { e.dataTransfer.setData('text/plain', b.id); e.dataTransfer.effectAllowed = 'move'; };
  boardGrid.appendChild(card);
  renderPreview(cv, b.objects || []);
}

function makeFolderCard(f) {
  const head = document.createElement('div');
  head.className = 'ficon';
  head.innerHTML = '<svg viewBox="0 0 24 24"><path d="M3 7a2 2 0 012-2h4l2 2h8a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2z"/></svg>';
  const count = Store.raw().list.filter(b => b.folder === f.id).length;
  const { card } = makeCard(f.name, head, count + ' ' + plural(count, 'доска', 'доски', 'досок'), [
    [ICONS.pen, 'Переименовать папку', () => renameFolder(f)],
    [ICONS.trash, 'Удалить папку', () => deleteFolder(f)],
  ], () => { session.homeFolder = f.id; renderHome(); });
  card.classList.add('fcard');
  card.ondragover = e => { e.preventDefault(); card.classList.add('dragover'); };
  card.ondragleave = () => card.classList.remove('dragover');
  card.ondrop = e => { card.classList.remove('dragover'); dropBoard(e, f.id); };
  boardGrid.appendChild(card);
}

function renderCrumbs() {
  const crumbs = document.getElementById('crumbs');
  crumbs.innerHTML = '';
  if (!session.homeFolder) {
    const t = document.createElement('span');
    t.textContent = 'Мои доски';
    crumbs.appendChild(t);
    return;
  }
  const f = Store.folders().find(x => x.id === session.homeFolder);
  const back = document.createElement('button');
  back.className = 'crumb-link';
  back.textContent = '← Мои доски';
  back.title = 'Перетащите доску сюда, чтобы вынести из папки';
  back.onclick = () => { session.homeFolder = null; renderHome(); };
  back.ondragover = e => { e.preventDefault(); back.classList.add('dragover'); };
  back.ondragleave = () => back.classList.remove('dragover');
  back.ondrop = e => { back.classList.remove('dragover'); dropBoard(e, null); };
  crumbs.append(back, document.createTextNode('/ ' + f.name));
}

export function renderHome() {
  if (session.homeFolder && !Store.folders().some(f => f.id === session.homeFolder)) session.homeFolder = null;
  renderCrumbs();
  boardGrid.innerHTML = '';
  const boards = session.homeFolder
    ? Store.raw().list.filter(b => b.folder === session.homeFolder)
    : Store.raw().list.filter(b => !b.folder || !Store.folders().some(f => f.id === b.folder));
  const emptyNote = text => {
    const d = document.createElement('div');
    d.className = 'empty-note';
    d.textContent = text;
    boardGrid.appendChild(d);
  };
  if (!session.homeFolder) {
    for (const f of Store.folders()) makeFolderCard(f);
    for (const b of boards) makeBoardCard(b);
    if (!boardGrid.children.length) emptyNote('Пока пусто — создайте папку или доску.');
  } else {
    if (!boards.length) emptyNote('Папка пуста. Создайте доску кнопкой «+ Новая доска» или перетащите её сюда из корня.');
    for (const b of boards) makeBoardCard(b);
  }
}
