import { CFG } from './config.js';
import { Store } from './store.js';
import { fileSafe, setStatus, uid } from './utils.js';

// Синхронизация досок с локальной папкой (File System Access API).
// «Синхронизировать…» на главной: выбираем рабочую папку — из неё (и её подпапок)
// забираются все *.board.json, подпапки становятся папками досок; обратно
// выгружаются все локальные доски. Дальнейшие правки молча дописываются в файл.

let dirHandle = null;
const fileIndex = new Map();   // board id -> {dirs: [..], fname}
export function syncInfo() { return dirHandle ? dirHandle.name : null; }

/* ---------- хранение handle между перезагрузками (IndexedDB) ---------- */
function idb() {
  return new Promise((res, rej) => {
    const rq = indexedDB.open('draw-sync', 1);
    rq.onupgradeneeded = () => rq.result.createObjectStore('kv');
    rq.onsuccess = () => res(rq.result);
    rq.onerror = () => rej(rq.error);
  });
}
async function saveHandle(h) {
  const db = await idb();
  await new Promise((res, rej) => {
    const t = db.transaction('kv', 'readwrite');
    t.objectStore('kv').put(h, 'dir');
    t.oncomplete = res; t.onerror = () => rej(t.error);
  });
}
async function loadHandle() {
  try {
    const db = await idb();
    return await new Promise((res, rej) => {
      const t = db.transaction('kv', 'readonly');
      const rq = t.objectStore('kv').get('dir');
      rq.onsuccess = () => res(rq.result || null); rq.onerror = () => rej(rq.error);
    });
  } catch (e) { return null; }
}

/* ---------- обход папки ---------- */
async function scan(dir, rel, out) {
  for await (const entry of dir.values()) {
    if (entry.kind === 'directory') await scan(entry, rel + entry.name + '/', out);
    else if (/\.board\.json$/i.test(entry.name)) out.push({ path: rel, handle: entry });
  }
}

function serializeSync(b) {
  return JSON.stringify({
    app: CFG.APP_ID, version: CFG.FILE_VERSION, id: b.id, name: b.name,
    objects: b.objects, view: b.view, updated: b.updated || 0,
  }, null, 1);
}

function folderById(id) { return Store.folders().find(f => f.id === id); }
function folderIdByDirName(name) {
  const f = Store.folders().find(x => x.name.toLowerCase() === String(name).toLowerCase());
  return f ? f.id : null;
}
function ensureFolderByDirName(name) {
  let id = folderIdByDirName(name);
  if (!id) { const f = { id: uid(), name }; Store.folders().push(f); Store.persist(); id = f.id; }
  return id;
}

// имя файла для доски; если занято чужой доской — добавляем -2, -3...
async function freeFileHandle(dir, b) {
  const base = fileSafe(b.name);
  for (let i = 0; i < 25; i++) {
    const fname = base + (i ? '-' + (i + 1) : '') + '.board.json';
    const fh = await dir.getFileHandle(fname, { create: true });
    let mine = true;
    try {
      const txt = await (await fh.getFile()).text();
      if (txt.trim()) {
        const d = JSON.parse(txt);
        if (d && d.id && d.id !== b.id) mine = false;
      }
    } catch (e) { /* пустой/битый — перезапишем */ }
    if (mine) return fh;
  }
  return dir.getFileHandle(base + '-x.board.json', { create: true });
}

async function writeBoard(b) {
  if (!dirHandle) return false;
  let target = dirHandle;
  const fd = b.folder ? folderById(b.folder) : null;
  const dirs = [];
  if (fd) { const dn = fileSafe(fd.name); dirs.push(dn); target = await dirHandle.getDirectoryHandle(dn, { create: true }); }
  const fh = await freeFileHandle(target, b);
  const w = await fh.createWritable();
  await w.write(serializeSync(b));
  await w.close();
  fileIndex.set(b.id, { dirs, fname: fh.name });
  return true;
}

async function deleteFile(entry) {
  if (!dirHandle) return;
  try {
    let dir = dirHandle;
    for (const d of entry.dirs) dir = await dir.getDirectoryHandle(d);
    await dir.removeEntry(entry.fname);
  } catch (e) { /* файла уже нет / нет доступа */ }
}

export async function removeBoardFile(b) {
  const e = fileIndex.get(b.id);
  if (e) { await deleteFile(e); fileIndex.delete(b.id); }
}

export async function syncNewBoard(b) {
  if (!dirHandle) return false;
  try { await writeBoard(b); return true; } catch (e) { return false; }
}

export async function syncRename(b) { await removeBoardFile(b); await syncNewBoard(b); }

export async function syncFolderRenamed(folderId, prevName) {
  if (!dirHandle) return;
  const boards = Store.raw().list.filter(b => b.folder === folderId);
  for (const b of boards) {
    const e = fileIndex.get(b.id);
    if (e) await deleteFile({ dirs: [fileSafe(prevName)], fname: e.fname });
  }
  for (const b of boards) await syncNewBoard(b);
}

export async function syncFolderCleared(ids, prevName) {
  if (!dirHandle) return;
  for (const id of ids) {
    const e = fileIndex.get(id);
    if (e) await deleteFile({ dirs: [fileSafe(prevName)], fname: e.fname });
    fileIndex.delete(id);
    const b = Store.raw().list.find(x => x.id === id);
    if (b) await syncNewBoard(b);
  }
}

/* ---------- основная синхронизация ---------- */
async function doSync(root) {
  const files = [];
  await scan(root, '', files);

  // подпапки верхнего уровня -> папки приложения
  const importedNames = new Set();
  for (const f of files) {
    const top = f.path.split('/')[0];
    if (top) ensureFolderByDirName(top);
  }

  const raw = Store.raw();
  const byId = new Map(raw.list.map(b => [b.id, b]));
  const keyOf = (folder, name) => (folder || '') + '|' + String(name).toLowerCase();
  const byKey = new Map(raw.list.map(b => [keyOf(b.folder, b.name), b]));
  let imported = 0, updated = 0;

  for (const f of files) {
    let d;
    try { d = JSON.parse(await (await f.handle.getFile()).text()); } catch (e) { continue; }
    const objects = Array.isArray(d) ? d : d.objects;
    if (!Array.isArray(objects)) continue;
    const name = String(d.name || f.handle.name.replace(/\.board\.json$/i, '') || 'Доска').slice(0, 60);
    const top = f.path.split('/')[0];
    const folder = top ? folderIdByDirName(top) : null;
    const diskUpdated = +d.updated || 0;
    let b = (d.id && byId.get(d.id)) || byKey.get(keyOf(folder, name));
    const dirs = f.path.split('/').filter(Boolean);
    if (b) {
      fileIndex.set(b.id, { dirs, fname: f.handle.name });
      if (diskUpdated > (b.updated || 0)) {
        b.name = name; b.objects = objects; b.view = d.view || b.view;
        b.folder = folder; b.updated = diskUpdated;
        updated++;
      }
    } else {
      b = Store.makeBoard(name, folder);
      b.objects = objects; b.view = (d.view && d.view.scale) ? d.view : b.view; b.updated = diskUpdated;
      raw.list.unshift(b);
      byId.set(b.id, b); byKey.set(keyOf(folder, name), b);
      imported++;
    }
    importedNames.add(b.id);
  }
  Store.persist();

  let exported = 0;
  for (const b of raw.list) {
    try { if (await writeBoard(b)) exported++; } catch (e) { /* нет доступа к имени/папке — пропускаем */ }
  }
  return { imported, updated, exported, dirName: root.name };
}

export async function syncWithFolder() {
  if (!window.showDirectoryPicker) throw new Error('браузер не умеет выбирать папки — нужен Edge/Chrome');
  if (!dirHandle) {
    dirHandle = await loadHandle();
    if (dirHandle) {
      let p = await dirHandle.queryPermission({ mode: 'readwrite' });
      if (p !== 'granted') p = await dirHandle.requestPermission({ mode: 'readwrite' });
      if (p !== 'granted') dirHandle = null;
    }
    if (!dirHandle) {
      dirHandle = await window.showDirectoryPicker({ mode: 'readwrite', id: 'draw-boards' });
      saveHandle(dirHandle).catch(() => {});
    }
  }
  return doSync(dirHandle);
}

// Молчаливая дозагрузка из папки: при первом же действии пользователя,
// если браузер сохранил право доступа, синхронизируем без единого вопроса.
export function syncAutoStart(onDone) {
  let tried = false;
  const run = () => {
    if (tried) return;
    tried = true;
    (async () => {
      try {
        const h = await loadHandle();
        if (!h || await h.queryPermission({ mode: 'readwrite' }) !== 'granted') return;
        dirHandle = h;
        onDone(await doSync(h));
      } catch (e) { tried = false; }
    })();
  };
  addEventListener('pointerdown', run);
  addEventListener('keydown', run);
}

/* ---------- живое зеркало: правки открытой доски улетают в файл ---------- */
const queue = new Map();
let timer = 0;
export function mirrorBoard(b) {
  if (!dirHandle) return;
  queue.set(b.id, b);
  clearTimeout(timer);
  timer = setTimeout(async () => {
    try {
      if (!dirHandle || await dirHandle.queryPermission({ mode: 'readwrite' }) !== 'granted') return;
      const items = [...queue.values()];
      queue.clear();
      for (const bb of items) await writeBoard(bb);
    } catch (e) { /* папку закрыли/удалили — переживём, кнопка синхронизации починит */ }
  }, 2000);
}

export function syncStatusLine() {
  const el = document.getElementById('syncInfo');
  if (!el) return;
  if (dirHandle) {
    el.textContent = 'Локальная папка: «' + dirHandle.name + '» — доски хранятся в ней, изменения сохраняются туда автоматически.';
    el.classList.add('show');
  } else {
    el.classList.remove('show');
  }
}

// вызов из домашней кнопки
export async function homeSyncClick(btn) {
  const old = btn.textContent;
  btn.disabled = true; btn.textContent = 'Синхронизация…';
  try {
    const r = await syncWithFolder();
    setStatus('Папка «' + r.dirName + '»: привезено ' + r.imported + ', обновлено ' + r.updated + ', сохранено ' + r.exported);
    return r;
  } catch (e) {
    if (e && e.name === 'AbortError') return null;  // выбрал «Отмена»
    setStatus('Синхронизация не удалась: ' + (e && e.message ? e.message : e));
    throw e;
  } finally {
    btn.disabled = false; btn.textContent = old;
  }
}
