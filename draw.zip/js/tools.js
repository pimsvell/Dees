import { CFG } from './config.js';
import { state, session } from './state.js';
import { toWorld, dist, uid, clamp, setStatus } from './utils.js';
import { findTopAt, smoothStroke, objectsBBox } from './scene.js';
import { render, hitTestCached, canvas } from './render.js';
import { openEditor, commitEditor } from './editor.js';
import { pushHistory } from './history.js';
import { save } from './store.js';
import { rt, cursorAt } from './rt.js';

// Инструменты: ввод с холста (pointer-события) и команды редактирования.

export const TOOL_KEYS = {
  KeyV: 'select', KeyH: 'hand', KeyP: 'pen', KeyM: 'marker', KeyD: 'dline', KeyL: 'line',
  KeyA: 'arrow', KeyR: 'rect', KeyO: 'ellipse', KeyN: 'note', KeyT: 'text', KeyE: 'eraser',
};

export function setTool(t) {
  if (state.readonly && t !== 'select' && t !== 'hand') return; // гость — только выбор и пан
  state.tool = t;
  document.querySelectorAll('.tool').forEach(b => b.classList.toggle('active', b.dataset.tool === t));
  document.querySelectorAll('.toolgroup').forEach(g => {
    const tools = (g.dataset.tools || '').split(' ');
    const primary = g.querySelector('.tool');
    primary.classList.toggle('active', tools.includes(t));
    const item = tools.includes(t) && g.querySelector('.menu-item[data-tool="' + t + '"]');
    if (item) { // главная кнопки группы показывает текущий под-инструмент
      primary.dataset.tool = t;
      primary.innerHTML = item.querySelector('svg').outerHTML +
        '<span class="hint">' + (item.dataset.hint || '') + '</span>';
    }
    g.querySelectorAll('.menu-item').forEach(mi => mi.classList.toggle('sel', mi.dataset.tool === t));
  });
  canvas.style.cursor = t === 'select' ? 'default' : t === 'hand' ? 'grab' : t === 'eraser' ? 'cell' : 'crosshair';
}

export function selectedObject() { return state.objects.find(o => o.id === state.selection); }

export function setColor(c) {
  state.color = c;
  const sel = selectedObject();
  if (sel && sel.type !== 'note') { sel.color = c; pushHistory(); render(); }
}

export function setWidth(w) {
  state.width = w;
  document.getElementById('widthLabel').textContent = w;
  const sel = selectedObject();
  if (sel && 'width' in sel) { sel.width = w; pushHistory(); render(); }
}

export function zoomAt(sx, sy, factor) {
  const v = state.view;
  const ns = Math.max(CFG.ZOOM_MIN, Math.min(CFG.ZOOM_MAX, v.scale * factor));
  const w = toWorld(sx, sy);
  v.scale = ns;
  v.x = sx - w.x * ns;
  v.y = sy - w.y * ns;
  render(); save();
}

/* --- операции над объектами --- */

export function moveObject(o, dx, dy) {
  if (o.type === 'path') o.points.forEach(q => { q.x += dx; q.y += dy; });
  else if (o.type === 'line' || o.type === 'arrow') { o.x1 += dx; o.y1 += dy; o.x2 += dx; o.y2 += dy; }
  else { o.x += dx; o.y += dy; }
}

export function deleteSelection() {
  if (!state.selection) return;
  state.objects = state.objects.filter(o => o.id !== state.selection);
  state.selection = null;
  pushHistory(); render();
}

export function duplicateSelected() {
  const sel = selectedObject();
  if (!sel) return;
  const cp = JSON.parse(JSON.stringify(sel));
  cp.id = Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
  moveObject(cp, 20, 20);
  state.objects.push(cp);
  state.selection = cp.id;
  pushHistory(); render();
}

export function clearBoard() {
  if (!state.objects.length || !confirm('Очистить всю доску?')) return;
  state.objects = []; state.selection = null;
  pushHistory(); render();
}

function eraseAt(p) {
  const o = findTopAt(p);
  if (!o) return;
  state.objects = state.objects.filter(x => x.id !== o.id);
  if (state.selection === o.id) state.selection = null;
  pushHistory(); render();
}

/* --- буфер обмена, порядок, «показать всё» --- */
const clipboard = { data: null };

export function copySelection() {
  const sel = selectedObject();
  if (!sel) return;
  clipboard.data = JSON.parse(JSON.stringify(sel));
  setStatus('Скопировано');
}

export function hasClipboard() { return !!clipboard.data; }

export function pasteClipboard() {
  if (!clipboard.data) return;
  const cp = JSON.parse(JSON.stringify(clipboard.data));
  cp.id = uid();
  moveObject(cp, 20, 20);
  state.objects.push(cp);
  state.selection = cp.id;
  pushHistory(); render();
}

export function reorder(dir) { // dir: 1 на перед, -1 на зад
  const sel = selectedObject();
  if (!sel) return;
  state.objects = state.objects.filter(o => o.id !== sel.id);
  if (dir > 0) state.objects.push(sel); else state.objects.unshift(sel);
  pushHistory(); render();
}

export function fitToContent() {
  if (!state.objects.length) return;
  const b = objectsBBox(state.objects);
  const pad = 60;
  const w = Math.max(b.x2 - b.x1, 1), h = Math.max(b.y2 - b.y1, 1);
  const s = clamp(Math.min((innerWidth - pad * 2) / w, (innerHeight - pad * 2) / h), CFG.ZOOM_MIN, CFG.ZOOM_MAX);
  state.view = { x: innerWidth / 2 - (b.x1 + w / 2) * s, y: innerHeight / 2 - (b.y1 + h / 2) * s, scale: s };
  render(); save();
}

/* --- создание объекта (draft) --- */

function createDraft(tool, p) {
  const uid = Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
  switch (tool) {
    case 'pen': case 'marker':
      return { id: uid, type: 'path', hl: tool === 'marker', color: state.color,
               width: tool === 'marker' ? Math.max(14, state.width * 4) : state.width, points: [p] };
    case 'line': case 'dline':
      return { id: uid, type: 'line', dash: tool === 'dline', color: state.color, width: state.width, x1: p.x, y1: p.y, x2: p.x, y2: p.y };
    case 'arrow':
      return { id: uid, type: 'arrow', color: state.color, width: state.width, x1: p.x, y1: p.y, x2: p.x, y2: p.y };
    case 'rect': case 'ellipse':
      return { id: uid, type: tool, color: state.color, width: state.width, x: p.x, y: p.y, w: 0, h: 0, _s: p };
  }
  return null;
}

function updateDraft(p) {
  const d = session.draft;
  if (d.type === 'path') {
    const last = d.points[d.points.length - 1];
    if (dist(last, p) > CFG.PEN_MIN_STEP / state.view.scale) d.points.push(p);
  } else if (d.x1 !== undefined) { d.x2 = p.x; d.y2 = p.y; }
  else {
    d.x = Math.min(d._s.x, p.x); d.y = Math.min(d._s.y, p.y);
    d.w = Math.abs(p.x - d._s.x); d.h = Math.abs(p.y - d._s.y);
  }
}

function commitDraft() {
  const d = session.draft;
  const big = d.type === 'path' ? d.points.length > 1
    : d.x1 !== undefined ? dist({ x: d.x1, y: d.y1 }, { x: d.x2, y: d.y2 }) > 3
    : d.w > 3 && d.h > 3;
  if (big) {
    delete d._s;
    if (d.type === 'path') d.points = smoothStroke(d.points);
    state.objects.push(d);
    pushHistory();
    state.selection = d.id;
  }
  session.draft = null;
}

/* --- указатель --- */

function onPointerDown(e) {
  commitEditor();
  canvas.setPointerCapture(e.pointerId);
  const p = toWorld(e.offsetX, e.offsetY);
  if (state.tool === 'hand' || session.spaceDown || e.button === 1) {
    session.drag = { mode: 'pan', sx: e.offsetX, sy: e.offsetY, vx: state.view.x, vy: state.view.y };
    canvas.style.cursor = 'grabbing';
    return;
  }
  if (state.readonly) return;            // гость: пан разрешён, любые правки — нет
  if (e.button !== 0) return;
  if (state.tool !== 'select' && state.selection) { state.selection = null; render(); }

  switch (state.tool) {
    case 'select': {
      const o = findTopAt(p);
      state.selection = o ? o.id : null;
      if (o) session.drag = { mode: 'move', id: o.id, lx: p.x, ly: p.y, moved: false };
      render();
      break;
    }
    case 'note': {
      const o = { id: Math.random().toString(36).slice(2, 10), type: 'note',
                  x: p.x - CFG.NOTE_W / 2, y: p.y - CFG.NOTE_H / 2, w: CFG.NOTE_W, h: CFG.NOTE_H, fill: CFG.NOTE_FILL, text: '' };
      state.objects.push(o); pushHistory(); state.selection = o.id; render();
      setTimeout(() => openEditor(o), 0); // после default-обработки mousedown (иначе фокус сразу теряется)
      break;
    }
    case 'text': {
      const o = { id: Math.random().toString(36).slice(2, 10), type: 'text', x: p.x, y: p.y, color: state.color, fontSize: CFG.TEXT_FONT, text: '' };
      state.objects.push(o); pushHistory(); state.selection = o.id; render();
      setTimeout(() => openEditor(o), 0);
      break;
    }
    case 'eraser':
      session.drag = { mode: 'erase' };
      eraseAt(p);
      break;
    default: {
      session.draft = createDraft(state.tool, p);
      if (session.draft) session.drag = { mode: 'draw' };
    }
  }
}

function onPointerMove(e) {
  const p = toWorld(e.offsetX, e.offsetY);
  if (rt.room) cursorAt(p.x, p.y);   // живой курсор для остальных участников
  const drag = session.drag;
  if (!drag) { updateCursor(p); return; }
  switch (drag.mode) {
    case 'pan':
      state.view.x = drag.vx + (e.offsetX - drag.sx);
      state.view.y = drag.vy + (e.offsetY - drag.sy);
      save(); render();
      break;
    case 'move': {
      const o = state.objects.find(o => o.id === drag.id);
      if (o) {
        moveObject(o, p.x - drag.lx, p.y - drag.ly);
        drag.lx = p.x; drag.ly = p.y; drag.moved = true;
        render();
      }
      break;
    }
    case 'draw': if (session.draft) { updateDraft(p); render(); } break;
    case 'erase': eraseAt(p); break;
  }
}

function onPointerUp() {
  const drag = session.drag;
  if (drag?.mode === 'draw' && session.draft) { commitDraft(); render(); }
  if (drag?.mode === 'move' && drag.moved) pushHistory();
  session.drag = null;
}

function onDblClick(e) {
  if (state.readonly) return;
  const o = findTopAt(toWorld(e.offsetX, e.offsetY));
  if (o && (o.type === 'note' || o.type === 'text')) { state.selection = o.id; openEditor(o); }
}

function onWheel(e) {
  e.preventDefault();
  if (e.ctrlKey || e.metaKey) {          // зум — как раньше, под курсором
    zoomAt(e.offsetX, e.offsetY, Math.exp(-e.deltaY * CFG.ZOOM_WHEEL));
    return;
  }
  if (e.shiftKey) {                      // Shift+колесо — горизонталь
    state.view.x -= (e.deltaX || e.deltaY);
    render(); save();
    return;
  }
  // обычный wheel — крупная прокрутка вниз/вверх; горизонталь без изменений
  state.view.y -= e.deltaY * CFG.PAN_WHEEL;
  state.view.x -= e.deltaX;
  render(); save();
}

function updateCursor(p) {
  if (state.tool === 'hand' || session.spaceDown) canvas.style.cursor = 'grab';
  else if (state.tool === 'eraser') canvas.style.cursor = 'cell';
  else if (state.tool === 'select') canvas.style.cursor = hitTestCached(p) ? 'move' : 'default';
  else canvas.style.cursor = 'crosshair';
}

export function bindCanvasInput() {
  canvas.addEventListener('pointerdown', onPointerDown);
  canvas.addEventListener('pointermove', onPointerMove);
  canvas.addEventListener('pointerup', onPointerUp);
  canvas.addEventListener('dblclick', onDblClick);
  canvas.addEventListener('wheel', onWheel, { passive: false });
}
